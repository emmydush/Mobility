<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Include database connection with robust path resolution
$rootPath = __DIR__;
$databasePath = $rootPath . '/api/config/database.php';

// If the direct path doesn't work, try alternative paths
if (!file_exists($databasePath)) {
    $databasePath = $rootPath . '/../api/config/database.php';
}

if (!file_exists($databasePath)) {
    $databasePath = $rootPath . '/../../api/config/database.php';
}

if (file_exists($databasePath)) {
    include_once $databasePath;
} else {
    die("Database configuration file not found");
}

// Include language functions
include_once 'api/config/languages.php';

// Set language if specified
if (isset($_GET['lang'])) {
    setCurrentLanguage($_GET['lang']);
}

// Get current language
$current_lang = getCurrentLanguage();

$username = $_SESSION['username'] ?? 'User';
$role = $_SESSION['role'] ?? 'cashier';

// Handle form submissions
$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $name = $_POST['name'] ?? '';
                $email = $_POST['email'] ?? '';
                $phone = $_POST['phone'] ?? '';
                $address = $_POST['address'] ?? '';
                
                if (!empty($name)) {
                    $query = "INSERT INTO customers (tenant_id, name, email, phone, address) VALUES (?, ?, ?, ?, ?)";
                    $stmt = $conn->prepare($query);
                    if ($stmt) {
                        $stmt->bind_param("issss", $_SESSION['tenant_id'], $name, $email, $phone, $address);
                        if ($stmt->execute()) {
                            $message = "Customer added successfully!";
                            $message_type = "success";
                        } else {
                            $message = "Error adding customer: " . $conn->error;
                            $message_type = "error";
                        }
                        $stmt->close();
                    } else {
                        $message = "Database error: " . $conn->error;
                        $message_type = "error";
                    }
                } else {
                    $message = "Customer name is required.";
                    $message_type = "error";
                }
                break;
                
            case 'delete':
                $id = $_POST['id'] ?? 0;
                if (is_numeric($id) && $id > 0) {
                    // First verify that the customer belongs to the current tenant
                    $verify_query = "SELECT id FROM customers WHERE id = ? AND tenant_id = ?";
                    $verify_stmt = $conn->prepare($verify_query);
                    $verify_stmt->bind_param("ii", $id, $_SESSION['tenant_id']);
                    $verify_stmt->execute();
                    $verify_result = $verify_stmt->get_result();
                    
                    if ($verify_result->num_rows > 0) {
                        // Check if customer has any sales records
                        $check_sales_query = "SELECT COUNT(*) as sales_count FROM sales WHERE customer_id = ? AND tenant_id = ?";
                        $check_sales_stmt = $conn->prepare($check_sales_query);
                        if ($check_sales_stmt) {
                            $check_sales_stmt->bind_param("ii", $id, $_SESSION['tenant_id']);
                            $check_sales_stmt->execute();
                            $sales_result = $check_sales_stmt->get_result();
                            $sales_data = $sales_result->fetch_assoc();
                            $sales_count = $sales_data['sales_count'];
                            $check_sales_stmt->close();
                            
                            if ($sales_count > 0) {
                                // Instead of deleting, mark as inactive
                                $update_query = "UPDATE customers SET status = 'inactive' WHERE id = ? AND tenant_id = ?";
                                $update_stmt = $conn->prepare($update_query);
                                if ($update_stmt) {
                                    $update_stmt->bind_param("ii", $id, $_SESSION['tenant_id']);
                                    if ($update_stmt->execute()) {
                                        $message = "Customer marked as inactive. Customer has $sales_count associated sales record(s) and cannot be permanently deleted.";
                                        $message_type = "success";
                                    } else {
                                        $message = "Error updating customer status: " . $conn->error;
                                        $message_type = "error";
                                    }
                                    $update_stmt->close();
                                } else {
                                    $message = "Database error: " . $conn->error;
                                    $message_type = "error";
                                }
                            } else {
                                // No sales records, safe to delete
                                $delete_query = "DELETE FROM customers WHERE id = ? AND tenant_id = ?";
                                $delete_stmt = $conn->prepare($delete_query);
                                if ($delete_stmt) {
                                    $delete_stmt->bind_param("ii", $id, $_SESSION['tenant_id']);
                                    if ($delete_stmt->execute()) {
                                        $message = "Customer deleted successfully!";
                                        $message_type = "success";
                                    } else {
                                        $message = "Error deleting customer: " . $conn->error;
                                        $message_type = "error";
                                    }
                                    $delete_stmt->close();
                                } else {
                                    $message = "Database error: " . $conn->error;
                                    $message_type = "error";
                                }
                            }
                        } else {
                            $message = "Database error: " . $conn->error;
                            $message_type = "error";
                        }
                    } else {
                        $message = "Customer not found or you don't have permission to delete it.";
                        $message_type = "error";
                    }
                    $verify_stmt->close();
                } else {
                    $message = "Invalid customer ID.";
                    $message_type = "error";
                }
                break;
        }
    }
}

// Fetch all customers (active and inactive) for the current tenant
$customers = array();
$query = "SELECT * FROM customers WHERE tenant_id = ? ORDER BY name";
$stmt = $conn->prepare($query);
if ($stmt) {
    $stmt->bind_param("i", $_SESSION['tenant_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $customers[] = $row;
    }
    $stmt->close();
}

// Fetch debtors (customers with negative balance) for the current tenant
$debtors = array();
$debtors_query = "SELECT * FROM customers WHERE balance < 0 AND tenant_id = ? ORDER BY balance ASC";
$debtors_stmt = $conn->prepare($debtors_query);
if ($debtors_stmt) {
    $debtors_stmt->bind_param("i", $_SESSION['tenant_id']);
    $debtors_stmt->execute();
    $debtors_result = $debtors_stmt->get_result();
    while ($row = $debtors_result->fetch_assoc()) {
        $debtors[] = $row;
    }
    $debtors_stmt->close();
}

// Fetch creditors (customers with positive balance) for the current tenant
$creditors = array();
$creditors_query = "SELECT * FROM customers WHERE balance > 0 AND tenant_id = ? ORDER BY balance DESC";
$creditors_stmt = $conn->prepare($creditors_query);
if ($creditors_stmt) {
    $creditors_stmt->bind_param("i", $_SESSION['tenant_id']);
    $creditors_stmt->execute();
    $creditors_result = $creditors_stmt->get_result();
    while ($row = $creditors_result->fetch_assoc()) {
        $creditors[] = $row;
    }
    $creditors_stmt->close();
}

// Calculate statistics
$total_customers = count($customers);
$total_debtors = count($debtors);
$total_creditors = count($creditors);

// Calculate total debt and credit amounts
$total_debt = 0;
$total_credit = 0;

foreach ($debtors as $debtor) {
    $total_debt += abs($debtor['balance']);
}

foreach ($creditors as $creditor) {
    $total_credit += $creditor['balance'];
}
?>

<!DOCTYPE html>
<html lang="<?php echo $current_lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customers - Complete Inventory Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="flex h-screen bg-gray-50">
        <!-- Sidebar -->
        <div class="w-64 bg-gradient-to-b from-green-700 to-green-900 shadow-lg">
            <div class="p-4 border-b border-green-600">
                <h1 class="text-xl font-bold text-white">IMS</h1>
                <p class="text-sm text-green-200">Inventory Management</p>
            </div>
            <nav class="mt-4">
                <a href="dashboard.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-tachometer-alt mr-3"></i>
                    <span><?php echo t('dashboard'); ?></span>
                </a>
                <a href="products.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-box mr-3"></i>
                    <span>Products</span>
                </a>
                <a href="categories.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-tags mr-3"></i>
                    <span>Categories</span>
                </a>
                <a href="purchases.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-shopping-cart mr-3"></i>
                    <span>Purchases</span>
                </a>
                <a href="expenses.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-file-invoice-dollar mr-3"></i>
                    <span>Expenses</span>
                </a>
                <a href="suppliers.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-truck mr-3"></i>
                    <span>Suppliers</span>
                </a>
                <a href="pos.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-cash-register mr-3"></i>
                    <span>Point of Sale</span>
                </a>
                <a href="stock-movements.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-exchange-alt mr-3"></i>
                    <span>Stock Movements</span>
                </a>
                <a href="customers.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-white bg-gradient-to-r from-green-500 to-green-600 border-l-4 border-green-300">
                    <i class="fas fa-users mr-3"></i>
                    <span>Customers</span>
                </a>
                <a href="sales.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-shopping-cart mr-3"></i>
                    <span>Sales</span>
                </a>
                <a href="reports.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-chart-bar mr-3"></i>
                    <span><?php echo t('reports'); ?></span>
                </a>
                <a href="advanced_reports.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-chart-line mr-3"></i>
                    <span>Advanced Reports</span>
                </a>
                <a href="users.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-user mr-3"></i>
                    <span><?php echo t('users'); ?></span>
                </a>
                <a href="settings.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-cog mr-3"></i>
                    <span><?php echo t('settings'); ?></span>
                </a>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="flex-1 flex flex-col overflow-hidden">
            <!-- Header -->
            <header class="flex items-center justify-between p-4 bg-gradient-to-r from-green-600 to-green-800 shadow">
                <h2 class="text-xl font-semibold text-white">Customer Management</h2>
                <div class="flex items-center space-x-4">
                    <!-- Language Selector -->
                    <div class="relative">
                        <select onchange="window.location.href=this.value" class="bg-green-600 text-white rounded px-2 py-1 text-sm">
                            <option value="?lang=en" <?php echo ($current_lang == 'en') ? 'selected' : ''; ?>>English</option>
                            <option value="?lang=fr" <?php echo ($current_lang == 'fr') ? 'selected' : ''; ?>>Français</option>
                            <option value="?lang=rw" <?php echo ($current_lang == 'rw') ? 'selected' : ''; ?>>Kinyarwanda</option>
                        </select>
                    </div>
                    <button id="add-customer-btn" class="px-4 py-2 text-sm bg-white text-green-600 rounded hover:bg-green-50 transition duration-200">
                        <i class="fas fa-plus mr-1"></i> Add Customer
                    </button>
                    <!-- User Profile Dropdown -->
                    <div class="relative">
                        <button id="user-menu-button" class="flex items-center space-x-2 text-white focus:outline-none">
                            <div class="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center">
                                <i class="fas fa-user text-white"></i>
                            </div>
                            <div class="text-left hidden md:block">
                                <p class="text-sm font-medium text-white"><?php echo htmlspecialchars($username); ?></p>
                                <p class="text-xs text-green-100 capitalize"><?php echo htmlspecialchars($role); ?></p>
                            </div>
                            <i class="fas fa-chevron-down text-green-200 text-xs"></i>
                        </button>
                        
                        <!-- Dropdown menu -->
                        <div id="user-dropdown" class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 hidden z-50">
                            <div class="px-4 py-2 border-b border-gray-200">
                                <p class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($username); ?></p>
                                <p class="text-xs text-gray-500 capitalize"><?php echo htmlspecialchars($role); ?></p>
                            </div>
                            <a href="profile.php?lang=<?php echo $current_lang; ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-user-circle mr-2"></i><?php echo t('profile'); ?>
                            </a>
                            <a href="logout.php?lang=<?php echo $current_lang; ?>" class="block px-4 py-2 text-sm text-red-600 hover:bg-gray-100">
                                <i class="fas fa-sign-out-alt mr-2"></i><?php echo t('logout'); ?>
                            </a>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Message Display -->
            <?php if ($message): ?>
                <div class="p-4 <?php echo $message_type === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'; ?>">
                    <div class="container mx-auto">
                        <?php echo htmlspecialchars($message); ?>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Customers Content -->
            <main class="flex-1 overflow-y-auto p-6">
                <!-- Customer Statistics -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                    <div class="bg-gradient-to-r from-green-500 to-green-600 rounded-lg shadow p-4 text-white">
                        <div class="text-green-100 text-sm">Total Customers</div>
                        <div class="text-2xl font-bold"><?php echo $total_customers; ?></div>
                    </div>
                    <div class="bg-gradient-to-r from-red-500 to-red-600 rounded-lg shadow p-4 text-white">
                        <div class="text-red-100 text-sm">Debtors</div>
                        <div class="text-2xl font-bold"><?php echo $total_debtors; ?></div>
                    </div>
                    <div class="bg-gradient-to-r from-green-500 to-green-600 rounded-lg shadow p-4 text-white">
                        <div class="text-green-100 text-sm">Creditors</div>
                        <div class="text-2xl font-bold"><?php echo $total_creditors; ?></div>
                    </div>
                    <div class="bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg shadow p-4 text-white">
                        <div class="text-purple-100 text-sm">Net Balance</div>
                        <div class="text-2xl font-bold">FRW<?php echo number_format($total_credit - $total_debt, 2); ?></div>
                    </div>
                </div>

                <!-- Debtors and Creditors Tabs -->
                <div class="mb-6">
                    <div class="border-b border-gray-200">
                        <nav class="flex space-x-8">
                            <button onclick="showTab('all')" id="tab-all" class="border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm border-green-500 text-green-600">
                                All Customers
                            </button>
                            <button onclick="showTab('debtors')" id="tab-debtors" class="border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm">
                                Debtors (<?php echo $total_debtors; ?>)
                            </button>
                            <button onclick="showTab('creditors')" id="tab-creditors" class="border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm">
                                Creditors (<?php echo $total_creditors; ?>)
                            </button>
                        </nav>
                    </div>
                </div>

                <!-- All Customers Tab -->
                <div id="tab-content-all" class="tab-content">
                    <div class="bg-white rounded-lg shadow overflow-hidden">
                        <div class="px-6 py-4 border-b border-gray-200">
                            <h3 class="text-lg font-medium text-gray-800">Customer List</h3>
                        </div>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Phone</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Balance</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    <?php if (count($customers) > 0): ?>
                                        <?php foreach ($customers as $customer): ?>
                                            <tr <?php echo $customer['status'] === 'inactive' ? 'class="bg-gray-50"' : ''; ?>>
                                                <td class="px-6 py-4 whitespace-nowrap">
                                                    <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($customer['name']); ?></div>
                                                </td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                    <?php echo htmlspecialchars($customer['email']); ?>
                                                </td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                    <?php echo htmlspecialchars($customer['phone']); ?>
                                                </td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm">
                                                    <?php if ($customer['balance'] < 0): ?>
                                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                                                            FRW<?php echo number_format(abs($customer['balance']), 2); ?> (Debt)
                                                        </span>
                                                    <?php elseif ($customer['balance'] > 0): ?>
                                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                                            FRW<?php echo number_format($customer['balance'], 2); ?> (Credit)
                                                        </span>
                                                    <?php else: ?>
                                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                                                            FRW0.00
                                                        </span>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm">
                                                    <?php if ($customer['status'] === 'active'): ?>
                                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                                            Active
                                                        </span>
                                                    <?php else: ?>
                                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                                                            Inactive (Deleted)
                                                        </span>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                                    <button class="text-green-600 hover:text-green-900 mr-3">Edit</button>
                                                    <?php if ($customer['status'] === 'active'): ?>
                                                        <form method="POST" class="inline" onsubmit="return confirm('Are you sure you want to delete this customer? Customers with sales records will be marked as inactive instead of being permanently deleted.')">
                                                            <input type="hidden" name="action" value="delete">
                                                            <input type="hidden" name="id" value="<?php echo $customer['id']; ?>">
                                                            <button type="submit" class="text-red-600 hover:text-red-900">Delete</button>
                                                        </form>
                                                    <?php else: ?>
                                                        <span class="text-gray-400">Deleted</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="7" class="px-6 py-4 text-center text-gray-500">
                                                No customers found
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Debtors Tab -->
                <div id="tab-content-debtors" class="tab-content hidden">
                    <div class="bg-white rounded-lg shadow overflow-hidden">
                        <div class="px-6 py-4 border-b border-gray-200">
                            <h3 class="text-lg font-medium text-gray-800">Debtors List</h3>
                            <p class="text-sm text-gray-500 mt-1">Customers who owe money to the business</p>
                        </div>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Phone</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount Owed</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    <?php if (count($debtors) > 0): ?>
                                        <?php foreach ($debtors as $debtor): ?>
                                            <tr>
                                                <td class="px-6 py-4 whitespace-nowrap">
                                                    <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($debtor['name']); ?></div>
                                                </td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                    <?php echo htmlspecialchars($debtor['email']); ?>
                                                </td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                    <?php echo htmlspecialchars($debtor['phone']); ?>
                                                </td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm">
                                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                                                        FRW<?php echo number_format(abs($debtor['balance']), 2); ?>
                                                    </span>
                                                </td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                                    <button class="text-green-600 hover:text-green-900 mr-3">View Details</button>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="5" class="px-6 py-4 text-center text-gray-500">
                                                No debtors found
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    <!-- Debt Summary -->
                    <div class="mt-6 bg-white rounded-lg shadow p-6">
                        <h3 class="text-lg font-medium text-gray-800 mb-4">Debt Summary</h3>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div class="border rounded-lg p-4">
                                <div class="text-gray-500 text-sm">Total Debtors</div>
                                <div class="text-2xl font-bold text-red-600"><?php echo $total_debtors; ?></div>
                            </div>
                            <div class="border rounded-lg p-4">
                                <div class="text-gray-500 text-sm">Total Amount Owed</div>
                                <div class="text-2xl font-bold text-red-600">FRW<?php echo number_format($total_debt, 2); ?></div>
                            </div>
                            <div class="border rounded-lg p-4">
                                <div class="text-gray-500 text-sm">Average Debt per Debtor</div>
                                <div class="text-2xl font-bold text-red-600">FRW<?php echo $total_debtors > 0 ? number_format($total_debt / $total_debtors, 2) : '0.00'; ?></div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Creditors Tab -->
                <div id="tab-content-creditors" class="tab-content hidden">
                    <div class="bg-white rounded-lg shadow overflow-hidden">
                        <div class="px-6 py-4 border-b border-gray-200">
                            <h3 class="text-lg font-medium text-gray-800">Creditors List</h3>
                            <p class="text-sm text-gray-500 mt-1">Customers to whom the business owes money</p>
                        </div>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Phone</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Credit Amount</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    <?php if (count($creditors) > 0): ?>
                                        <?php foreach ($creditors as $creditor): ?>
                                            <tr>
                                                <td class="px-6 py-4 whitespace-nowrap">
                                                    <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($creditor['name']); ?></div>
                                                </td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                    <?php echo htmlspecialchars($creditor['email']); ?>
                                                </td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                    <?php echo htmlspecialchars($creditor['phone']); ?>
                                                </td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm">
                                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                                        FRW<?php echo number_format($creditor['balance'], 2); ?>
                                                    </span>
                                                </td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                                    <button class="text-green-600 hover:text-green-900 mr-3">View Details</button>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="5" class="px-6 py-4 text-center text-gray-500">
                                                No creditors found
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    <!-- Credit Summary -->
                    <div class="mt-6 bg-white rounded-lg shadow p-6">
                        <h3 class="text-lg font-medium text-gray-800 mb-4">Credit Summary</h3>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div class="border rounded-lg p-4">
                                <div class="text-gray-500 text-sm">Total Creditors</div>
                                <div class="text-2xl font-bold text-green-600"><?php echo $total_creditors; ?></div>
                            </div>
                            <div class="border rounded-lg p-4">
                                <div class="text-gray-500 text-sm">Total Credit Amount</div>
                                <div class="text-2xl font-bold text-green-600">FRW<?php echo number_format($total_credit, 2); ?></div>
                            </div>
                            <div class="border rounded-lg p-4">
                                <div class="text-gray-500 text-sm">Average Credit per Creditor</div>
                                <div class="text-2xl font-bold text-green-600">FRW<?php echo $total_creditors > 0 ? number_format($total_credit / $total_creditors, 2) : '0.00'; ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Add/Edit Customer Modal -->
    <div id="customer-modal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
        <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div class="mt-3">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Add Customer</h3>
                <form method="POST">
                    <input type="hidden" name="action" value="add">
                    <div class="mb-4">
                        <label class="block text-gray-700 text-sm font-bold mb-2" for="customer-name">
                            Name
                        </label>
                        <input type="text" id="customer-name" name="name" required
                            class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                    </div>
                    <div class="mb-4">
                        <label class="block text-gray-700 text-sm font-bold mb-2" for="customer-email">
                            Email
                        </label>
                        <input type="email" id="customer-email" name="email"
                            class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                    </div>
                    <div class="mb-4">
                        <label class="block text-gray-700 text-sm font-bold mb-2" for="customer-phone">
                            Phone
                        </label>
                        <input type="text" id="customer-phone" name="phone"
                            class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                    </div>
                    <div class="mb-4">
                        <label class="block text-gray-700 text-sm font-bold mb-2" for="customer-address">
                            Address
                        </label>
                        <textarea id="customer-address" name="address" rows="3"
                            class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"></textarea>
                    </div>
                    <div class="flex items-center justify-between mt-6">
                        <button type="button" id="cancel-customer-btn"
                            class="px-4 py-2 text-sm bg-gray-600 text-white rounded hover:bg-gray-700">
                            Cancel
                        </button>
                        <button type="submit"
                            class="px-4 py-2 text-sm bg-green-600 text-white rounded hover:bg-green-700">
                            Save Customer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Tab functionality
        function showTab(tabName) {
            // Hide all tab contents
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.add('hidden');
            });
            
            // Remove active class from all tabs
            document.querySelectorAll('nav button').forEach(tab => {
                tab.classList.remove('border-green-500', 'text-green-600');
                tab.classList.add('border-transparent', 'text-gray-500');
            });
            
            // Show selected tab content
            document.getElementById('tab-content-' + tabName).classList.remove('hidden');
            
            // Add active class to selected tab
            document.getElementById('tab-' + tabName).classList.remove('border-transparent', 'text-gray-500');
            document.getElementById('tab-' + tabName).classList.add('border-green-500', 'text-green-600');
        }
        
        // Simple JavaScript for modal functionality
        document.addEventListener('DOMContentLoaded', function() {
            const modal = document.getElementById('customer-modal');
            const addCustomerBtn = document.getElementById('add-customer-btn');
            const cancelBtn = document.getElementById('cancel-customer-btn');
            
            addCustomerBtn.addEventListener('click', function() {
                modal.classList.remove('hidden');
            });
            
            cancelBtn.addEventListener('click', function() {
                modal.classList.add('hidden');
            });
            
            // Close modal when clicking outside
            window.addEventListener('click', function(event) {
                if (event.target === modal) {
                    modal.classList.add('hidden');
                }
            });
            
            // User profile dropdown toggle
            const userMenuButton = document.getElementById('user-menu-button');
            const userDropdown = document.getElementById('user-dropdown');
            
            if (userMenuButton && userDropdown) {
                userMenuButton.addEventListener('click', function(e) {
                    e.stopPropagation();
                    userDropdown.classList.toggle('hidden');
                });
                
                // Close dropdown when clicking outside
                document.addEventListener('click', function() {
                    userDropdown.classList.add('hidden');
                });
                
                // Prevent closing when clicking inside dropdown
                userDropdown.addEventListener('click', function(e) {
                    e.stopPropagation();
                });
            }
        });
    </script>
</body>
</html>