<?php
session_start();

// Include database connection
include_once 'api/config/database.php';

// Include language functions
include_once 'api/config/languages.php';

// Set language if specified
if (isset($_GET['lang'])) {
    setCurrentLanguage($_GET['lang']);
}

// Get current language
$current_lang = getCurrentLanguage();

$error_message = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (!empty($username) && !empty($password)) {
        // Check if user exists and get tenant information
        $query = "SELECT u.id, u.username, u.password, u.role, t.tenant_id, t.business_name FROM users u LEFT JOIN tenants t ON u.tenant_id = t.id WHERE u.username = ? OR u.email = ?";
        $stmt = $conn->prepare($query);
        if ($stmt) {
            $stmt->bind_param("ss", $username, $username);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $user = $result->fetch_assoc();
                if (password_verify($password, $user['password'])) {
                    // Check if user is a super admin
                    if ($user['role'] === 'super_admin') {
                        // Super admin login successful
                        $_SESSION['user_id'] = $user['id'];
                        $_SESSION['username'] = $user['username'];
                        $_SESSION['role'] = $user['role'];
                        
                        // Redirect to super admin dashboard
                        header("Location: super_admin_dashboard.php");
                        exit();
                    }
                    // Check if tenant is active
                    else if ($user['tenant_id'] && !$user['business_name']) {
                        $error_message = "Your business account is inactive. Please contact support.";
                    } else if (!$user['tenant_id']) {
                        $error_message = "No business account assigned to your user. Please contact support.";
                    } else {
                        // Regular user login successful
                        $_SESSION['user_id'] = $user['id'];
                        $_SESSION['username'] = $user['username'];
                        $_SESSION['role'] = $user['role'];
                        $_SESSION['tenant_id'] = $user['tenant_id'];
                        
                        // Redirect to dashboard
                        header("Location: dashboard.php");
                        exit();
                    }
                } else {
                    $error_message = "Invalid password";
                }
            } else {
                $error_message = "User not found";
            }
            $stmt->close();
        } else {
            $error_message = "Database error: " . $conn->error;
        }
    } else {
        $error_message = "Username and password are required";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo t('login'); ?> - <?php echo t('inventory_management'); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background-color: #f5f7fa;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        /* Vibration animation for register button */
        @keyframes vibrate {
            0% { transform: translateX(0); }
            25% { transform: translateX(-2px); }
            50% { transform: translateX(2px); }
            75% { transform: translateX(-2px); }
            100% { transform: translateX(0); }
        }

        .vibrate-animation {
            animation: vibrate 0.3s ease-in-out infinite;
        }

        header a:hover {
            background-color: rgba(255,255,255,0.2);
        }

        .container {
            display: flex;
            width: 100%;
            max-width: 900px;
            height: 550px;
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
        }

        .left-side {
            flex: 1;
            background: white;
            padding: 50px 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .right-side {
            flex: 1;
            background: linear-gradient(135deg, #2e7d32, #388e3c, #43a047, #4caf50);
            padding: 50px 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            color: white;
            text-align: center;
        }

        .form-title {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 10px;
            color: #333;
        }

        .form-subtitle {
            font-size: 14px;
            color: #666;
            margin-bottom: 30px;
        }

        .input-group {
            margin-bottom: 20px;
        }

        .input-group label {
            display: block;
            margin-bottom: 8px;
            font-size: 14px;
            font-weight: 500;
            color: #333;
        }

        .input-group input {
            width: 100%;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 10px;
            font-size: 16px;
            transition: all 0.3s ease;
        }

        .input-group input:focus {
            border-color: #4caf50;
            outline: none;
            box-shadow: 0 0 0 3px rgba(76, 175, 80, 0.2);
        }

        .signin-button {
            width: 100%;
            padding: 15px;
            background: #4caf50;
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 10px;
        }

        .signin-button:hover {
            background: #43a047;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(76, 175, 80, 0.3);
        }

        .social-login {
            margin-top: 30px;
            text-align: center;
        }

        .social-login p {
            position: relative;
            color: #666;
            margin-bottom: 20px;
        }

        .social-login p:before,
        .social-login p:after {
            content: "";
            position: absolute;
            top: 50%;
            width: 30%;
            height: 1px;
            background: #ddd;
        }

        .social-login p:before {
            left: 0;
        }

        .social-login p:after {
            right: 0;
        }

        .social-icons {
            display: flex;
            justify-content: center;
            gap: 20px;
        }

        .social-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #f5f7fa;
            color: #4caf50;
            font-size: 20px;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .social-icon:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .facebook:hover {
            background: #3b5998;
            color: white;
        }

        .google:hover {
            background: #db4437;
            color: white;
        }

        .linkedin:hover {
            background: #0077b5;
            color: white;
        }

        .welcome-title {
            font-size: 36px;
            font-weight: 700;
            margin-bottom: 20px;
        }

        .welcome-text {
            font-size: 16px;
            line-height: 1.6;
            margin-bottom: 30px;
            opacity: 0.9;
        }

        .signup-link {
            display: inline-block;
            padding: 12px 30px;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            text-decoration: none;
            border-radius: 30px;
            font-weight: 500;
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        .signup-link:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateY(-2px);
        }

        .error-message {
            background: #ffebee;
            color: #c62828;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        /* Responsive design */
        @media (max-width: 768px) {
            .container {
                flex-direction: column;
                height: auto;
                max-width: 450px;
            }

            .left-side,
            .right-side {
                padding: 30px 25px;
            }

            .right-side {
                padding: 40px 25px;
            }

            .welcome-title {
                font-size: 28px;
            }

            .form-title {
                font-size: 28px;
            }
            
            header {
                padding: 0 10px;
                height: 56px;
            }
            
            .header-content {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
            
            .header-nav {
                align-self: flex-end;
            }
        }

        @media (max-width: 480px) {
            body {
                padding: 10px;
            }

            .container {
                max-width: 100%;
            }

            .left-side,
            .right-side {
                padding: 25px 20px;
            }

            .form-title {
                font-size: 24px;
            }

            .welcome-title {
                font-size: 24px;
            }

            .input-group input {
                padding: 12px;
            }

            .signin-button {
                padding: 12px;
            }

            .social-icon {
                width: 45px;
                height: 45px;
                font-size: 18px;
            }
            
            h1 {
                font-size: 20px;
            }
            
            .language-selector {
                padding: 3px 8px;
                font-size: 12px;
            }
            
            .register-link {
                padding: 6px 12px;
                font-size: 12px;
            }
        }
        
        @media (max-width: 360px) {
            .social-icons {
                gap: 10px;
            }
            
            .social-icon {
                width: 40px;
                height: 40px;
            }
            
            .form-subtitle {
                font-size: 14px;
            }
            
            .welcome-text {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header style="background: linear-gradient(135deg, #2e7d32, #388e3c); box-shadow: 0 2px 10px rgba(0,0,0,0.1); position: fixed; top: 0; width: 100%; z-index: 1000;">
        <div class="header-content" style="max-width: 1200px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; padding: 0 20px; height: 64px;">
            <div style="display: flex; align-items: center;">
                <i class="fas fa-boxes" style="color: white; font-size: 24px; margin-right: 10px;"></i>
                <h1 style="color: white; font-size: 24px; font-weight: 600; margin: 0;"><?php echo t('mobility_inventory'); ?></h1>
            </div>
            <div class="header-nav" style="display: flex; align-items: center; gap: 15px;">
                <!-- Language Selector -->
                <div class="relative language-selector">
                    <select onchange="window.location.href=this.value" style="background: rgba(255, 255, 255, 0.2); color: white; border: 1px solid rgba(255, 255, 255, 0.3); border-radius: 20px; padding: 5px 10px; font-size: 14px; appearance: none; padding-right: 25px; cursor: pointer;">
                        <option value="?lang=en" <?php echo ($current_lang == 'en') ? 'selected' : ''; ?>>EN</option>
                        <option value="?lang=fr" <?php echo ($current_lang == 'fr') ? 'selected' : ''; ?>>FR</option>
                        <option value="?lang=rw" <?php echo ($current_lang == 'rw') ? 'selected' : ''; ?>>RW</option>
                    </select>
                    <i class="fas fa-chevron-down" style="color: white; position: absolute; right: 10px; top: 50%; transform: translateY(-50%); font-size: 10px;"></i>
                </div>
                <nav>
                    <a href="register_tenant.php" class="register-link" style="color: rgba(255, 255, 255, 0.9); text-decoration: none; font-weight: 500; padding: 8px 16px; border-radius: 20px; transition: background-color 0.3s;" onmouseover="this.style.backgroundColor='rgba(255,255,255,0.2)'" onmouseout="this.style.backgroundColor='transparent'"><?php echo t('register'); ?></a>
                </nav>
            </div>
        </div>
    </header>

    <div class="container" style="margin-top: 80px;">
        <!-- Left side - Login form -->
        <div class="left-side">
            <?php if ($error_message): ?>
                <div class="error-message">
                    <?php echo htmlspecialchars($error_message); ?>
                </div>
            <?php endif; ?>

            <h1 class="form-title"><?php echo t('signin'); ?></h1>
            <p class="form-subtitle"><?php echo t('enter_your_credentials'); ?></p>

            <form method="POST">
                <div class="input-group">
                    <label for="username"><?php echo t('username'); ?></label>
                    <input type="text" id="username" name="username" required placeholder="<?php echo t('enter_your_username'); ?>">
                </div>

                <div class="input-group">
                    <label for="password"><?php echo t('password'); ?></label>
                    <input type="password" id="password" name="password" required placeholder="<?php echo t('enter_your_password'); ?>">
                </div>

                <button type="submit" class="signin-button"><?php echo t('signin'); ?></button>
            </form>

            <div class="social-login">
                <p><?php echo t('or_signin_with'); ?></p>
                <div class="social-icons">
                    <div class="social-icon facebook">
                        <i class="fab fa-facebook-f"></i>
                    </div>
                    <div class="social-icon google">
                        <i class="fab fa-google"></i>
                    </div>
                    <div class="social-icon linkedin">
                        <i class="fab fa-linkedin-in"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right side - Welcome message -->
        <div class="right-side">
            <h2 class="welcome-title"><?php echo t('welcome_back'); ?></h2>
            <p class="welcome-text">
                <?php echo t('access_inventory_system'); ?>
            </p>
            <a href="register_tenant.php" class="signup-link"><?php echo t('no_account_yet'); ?> <?php echo t('signup'); ?>.</a>
        </div>
    </div>

    <script>
        // Add simple hover effects for social icons
        document.querySelectorAll('.social-icon').forEach(icon => {
            icon.addEventListener('click', function() {
                // In a real application, this would trigger the social login
                alert('Social login would be implemented here');
            });
        });
        
        // Vibration animation for register button
        document.addEventListener('DOMContentLoaded', function() {
            const registerButton = document.querySelector('a[href="register_tenant.php"]');
            
            // Function to toggle vibration
            function toggleVibration() {
                registerButton.classList.toggle('vibrate-animation');
            }
            
            // Start vibration after 1 second
            setTimeout(toggleVibration, 1000);
            
            // Toggle vibration every 3 seconds
            setInterval(toggleVibration, 3000);
        });
    </script>
</body>
</html>