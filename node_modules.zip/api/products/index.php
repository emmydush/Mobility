<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';

// Check if user is logged in
session_start();
if (!isset($_SESSION['user_id']) || !isset($_SESSION['tenant_id'])) {
    http_response_code(401);
    echo json_encode(array("success" => false, "message" => "Unauthorized"));
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        // Get all products or single product if ID is provided
        if (isset($_GET['id'])) {
            $id = $_GET['id'];
            $query = "SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.id = ? AND p.tenant_id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ii", $id, $_SESSION['tenant_id']);
        } else {
            $query = "SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.tenant_id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("i", $_SESSION['tenant_id']);
        }
        
        $stmt->execute();
        $result = $stmt->get_result();
        $products = array();
        
        while ($row = $result->fetch_assoc()) {
            array_push($products, $row);
        }
        
        echo json_encode(array("success" => true, "data" => $products));
        break;

    case 'POST':
        // Create new product
        $data = json_decode(file_get_contents("php://input"));
        
        if (!empty($data->name) && !empty($data->price)) {
            $query = "INSERT INTO products (tenant_id, name, description, sku, barcode, category_id, supplier_id, price, cost_price, stock_quantity, minimum_stock, maximum_stock, expiry_date, status, created_by) 
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($query);
            // Set default values for optional fields
            $sku = $data->sku ?? null;
            $barcode = $data->barcode ?? null;
            $description = $data->description ?? '';
            $supplier_id = $data->supplier_id ?? null;
            $cost_price = $data->cost_price ?? 0;
            $stock_quantity = $data->stock_quantity ?? 0;
            $minimum_stock = $data->minimum_stock ?? 10;
            $maximum_stock = $data->maximum_stock ?? null;
            $expiry_date = $data->expiry_date ?? null;
            $status = $data->status ?? 'active';
            $created_by = $data->created_by ?? null;
            
            $stmt->bind_param("isssssiiidiissi", 
                $_SESSION['tenant_id'],
                $data->name, 
                $description,
                $sku,
                $barcode,
                $data->category_id,
                $supplier_id,
                $data->price,
                $cost_price,
                $stock_quantity,
                $minimum_stock,
                $maximum_stock,
                $expiry_date,
                $status,
                $created_by
            );
            
            if ($stmt->execute()) {
                http_response_code(201);
                echo json_encode(array(
                    "success" => true,
                    "message" => "Product created successfully",
                    "id" => $stmt->insert_id
                ));
            } else {
                http_response_code(500);
                echo json_encode(array("success" => false, "message" => "Unable to create product: " . $conn->error));
            }
        } else {
            http_response_code(400);
            echo json_encode(array("success" => false, "message" => "Name and price are required"));
        }
        break;

    case 'PUT':
        // Update product
        $data = json_decode(file_get_contents("php://input"));
        
        if (!empty($data->id)) {
            // First verify that the product belongs to the current tenant
            $verify_query = "SELECT id FROM products WHERE id = ? AND tenant_id = ?";
            $verify_stmt = $conn->prepare($verify_query);
            $verify_stmt->bind_param("ii", $data->id, $_SESSION['tenant_id']);
            $verify_stmt->execute();
            $verify_result = $verify_stmt->get_result();
            
            if ($verify_result->num_rows > 0) {
                $query = "UPDATE products SET 
                         name = ?, 
                         description = ?, 
                         sku = ?,
                         barcode = ?,
                         category_id = ?,
                         supplier_id = ?,
                         price = ?,
                         cost_price = ?,
                         stock_quantity = ?,
                         minimum_stock = ?,
                         maximum_stock = ?,
                         expiry_date = ?,
                         status = ?,
                         created_by = ?
                         WHERE id = ? AND tenant_id = ?";
                
                $stmt = $conn->prepare($query);
                // Set default values for optional fields
                $sku = $data->sku ?? null;
                $barcode = $data->barcode ?? null;
                $description = $data->description ?? '';
                $supplier_id = $data->supplier_id ?? null;
                $cost_price = $data->cost_price ?? 0;
                $stock_quantity = $data->stock_quantity ?? 0;
                $minimum_stock = $data->minimum_stock ?? 10;
                $maximum_stock = $data->maximum_stock ?? null;
                $expiry_date = $data->expiry_date ?? null;
                $status = $data->status ?? 'active';
                $created_by = $data->created_by ?? null;
                
                $stmt->bind_param("ssssiiidiissiiii", 
                    $data->name, 
                    $description,
                    $sku,
                    $barcode,
                    $data->category_id,
                    $supplier_id,
                    $data->price,
                    $cost_price,
                    $stock_quantity,
                    $minimum_stock,
                    $maximum_stock,
                    $expiry_date,
                    $status,
                    $created_by,
                    $data->id,
                    $_SESSION['tenant_id']
                );
                
                if ($stmt->execute()) {
                    echo json_encode(array("success" => true, "message" => "Product updated successfully"));
                } else {
                    http_response_code(500);
                    echo json_encode(array("success" => false, "message" => "Unable to update product: " . $conn->error));
                }
            } else {
                http_response_code(404);
                echo json_encode(array("success" => false, "message" => "Product not found or you don't have permission to update it"));
            }
            $verify_stmt->close();
        } else {
            http_response_code(400);
            echo json_encode(array("success" => false, "message" => "Product ID is required"));
        }
        break;

    case 'DELETE':
        // Delete product
        $data = json_decode(file_get_contents("php://input"));
        
        if (!empty($data->id)) {
            // First verify that the product belongs to the current tenant
            $verify_query = "SELECT id FROM products WHERE id = ? AND tenant_id = ?";
            $verify_stmt = $conn->prepare($verify_query);
            $verify_stmt->bind_param("ii", $data->id, $_SESSION['tenant_id']);
            $verify_stmt->execute();
            $verify_result = $verify_stmt->get_result();
            
            if ($verify_result->num_rows > 0) {
                $query = "DELETE FROM products WHERE id = ? AND tenant_id = ?";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("ii", $data->id, $_SESSION['tenant_id']);
                
                if ($stmt->execute()) {
                    echo json_encode(array("success" => true, "message" => "Product deleted successfully"));
                } else {
                    http_response_code(500);
                    echo json_encode(array("success" => false, "message" => "Unable to delete product"));
                }
            } else {
                http_response_code(404);
                echo json_encode(array("success" => false, "message" => "Product not found or you don't have permission to delete it"));
            }
            $verify_stmt->close();
        } else {
            http_response_code(400);
            echo json_encode(array("success" => false, "message" => "Product ID is required"));
        }
        break;
}
?>