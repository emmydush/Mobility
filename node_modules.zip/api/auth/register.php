<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';

$data = json_decode(file_get_contents("php://input"));

if (!empty($data->username) && !empty($data->password) && !empty($data->email) && !empty($data->role)) {
    $username = $data->username;
    $password = password_hash($data->password, PASSWORD_DEFAULT);
    $email = $data->email;
    $role = $data->role;
    
    // Check if username or email already exists
    $check_query = "SELECT id FROM users WHERE username = ? OR email = ?";
    $check_stmt = $conn->prepare($check_query);
    $check_stmt->bind_param("ss", $username, $email);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows > 0) {
        http_response_code(400);
        echo json_encode(array("success" => false, "message" => "Username or email already exists"));
        exit();
    }
    
    $query = "INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssss", $username, $password, $email, $role);
    
    if ($stmt->execute()) {
        $user_id = $stmt->insert_id;
        http_response_code(201);
        echo json_encode(array(
            "success" => true,
            "message" => "User created successfully",
            "user" => array(
                "id" => $user_id,
                "username" => $username,
                "email" => $email,
                "role" => $role
            )
        ));
    } else {
        http_response_code(500);
        echo json_encode(array("success" => false, "message" => "Unable to create user"));
    }
} else {
    http_response_code(400);
    echo json_encode(array("success" => false, "message" => "All fields are required"));
}
?>
