<?php
// Multi-User Database Initialization Script
// This script creates a comprehensive database for multi-user inventory management

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'mobility_db');

// Connect to MySQL
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS);

if ($conn->connect_error) {
    die(json_encode([
        "success" => false,
        "message" => "Connection failed: " . $conn->connect_error
    ]));
}

// Create database if it doesn't exist
$sql = "CREATE DATABASE IF NOT EXISTS " . DB_NAME . " CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
if ($conn->query($sql) === FALSE) {
    die(json_encode([
        "success" => false,
        "message" => "Error creating database: " . $conn->error
    ]));
}

$conn->select_db(DB_NAME);

// Array of table creation queries for multi-user support
$tables = [
    // Users table with roles and permissions
    "CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        email VARCHAR(100) NOT NULL UNIQUE,
        phone VARCHAR(20),
        address TEXT,
        role ENUM('admin', 'manager', 'cashier') NOT NULL,
        status ENUM('active', 'inactive') DEFAULT 'active',
        last_login DATETIME,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        created_by INT,
        FOREIGN KEY (created_by) REFERENCES users(id)
    )",

    // User sessions for multi-device login management
    "CREATE TABLE IF NOT EXISTS user_sessions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        token VARCHAR(255) NOT NULL,
        device_info TEXT,
        ip_address VARCHAR(45),
        last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        expires_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )",

    // Activity log for audit trail
    "CREATE TABLE IF NOT EXISTS activity_log (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        action_type VARCHAR(50) NOT NULL,
        table_name VARCHAR(50) NOT NULL,
        record_id INT,
        old_values TEXT,
        new_values TEXT,
        ip_address VARCHAR(45),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )",

    // Settings table for system configuration
    "CREATE TABLE IF NOT EXISTS settings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        setting_key VARCHAR(50) NOT NULL UNIQUE,
        setting_value TEXT,
        setting_type VARCHAR(20) DEFAULT 'string',
        description TEXT,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        updated_by INT,
        FOREIGN KEY (updated_by) REFERENCES users(id)
    )",

    // Categories for products
    "CREATE TABLE IF NOT EXISTS categories (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        created_by INT,
        FOREIGN KEY (created_by) REFERENCES users(id)
    )",

    // Suppliers table
    "CREATE TABLE IF NOT EXISTS suppliers (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        contact_person VARCHAR(100),
        email VARCHAR(100),
        phone VARCHAR(20),
        address TEXT,
        status ENUM('active', 'inactive') DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        created_by INT,
        FOREIGN KEY (created_by) REFERENCES users(id)
    )",

    // Customers with loyalty system
    "CREATE TABLE IF NOT EXISTS customers (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100),
        phone VARCHAR(20),
        address TEXT,
        loyalty_points INT DEFAULT 0,
        total_purchases DECIMAL(12,2) DEFAULT 0,
        balance DECIMAL(12,2) DEFAULT 0,
        credit_limit DECIMAL(12,2) DEFAULT 0,
        status ENUM('active', 'inactive') DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        created_by INT,
        FOREIGN KEY (created_by) REFERENCES users(id)
    )",

    // Products table with categories and suppliers
    "CREATE TABLE IF NOT EXISTS products (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        description TEXT,
        sku VARCHAR(50) UNIQUE,
        barcode VARCHAR(50) UNIQUE,
        category_id INT,
        supplier_id INT,
        price DECIMAL(12,2) NOT NULL,
        cost_price DECIMAL(12,2) NOT NULL,
        wholesale_price DECIMAL(12,2),
        stock_quantity INT NOT NULL DEFAULT 0,
        minimum_stock INT NOT NULL DEFAULT 10,
        maximum_stock INT,
        expiry_date DATE,
        status ENUM('active', 'inactive') DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        created_by INT,
        FOREIGN KEY (category_id) REFERENCES categories(id),
        FOREIGN KEY (supplier_id) REFERENCES suppliers(id),
        FOREIGN KEY (created_by) REFERENCES users(id)
    )",

    // Stock movements with batch tracking
    "CREATE TABLE IF NOT EXISTS stock_movements (
        id INT AUTO_INCREMENT PRIMARY KEY,
        product_id INT NOT NULL,
        type ENUM('in', 'out', 'transfer', 'adjustment') NOT NULL,
        quantity INT NOT NULL,
        unit_price DECIMAL(12,2) NOT NULL,
        total_value DECIMAL(12,2) NOT NULL,
        reference_number VARCHAR(50),
        batch_number VARCHAR(50),
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        created_by INT,
        FOREIGN KEY (product_id) REFERENCES products(id),
        FOREIGN KEY (created_by) REFERENCES users(id)
    )",

    // Sales and transactions
    "CREATE TABLE IF NOT EXISTS sales (
        id INT AUTO_INCREMENT PRIMARY KEY,
        invoice_number VARCHAR(50) UNIQUE,
        customer_id INT,
        subtotal DECIMAL(12,2) NOT NULL,
        tax_amount DECIMAL(12,2) DEFAULT 0,
        discount_amount DECIMAL(12,2) DEFAULT 0,
        total_amount DECIMAL(12,2) NOT NULL,
        amount_paid DECIMAL(12,2) DEFAULT 0,
        amount_due DECIMAL(12,2) DEFAULT 0,
        payment_method ENUM('cash', 'card', 'mobile_money', 'bank_transfer', 'credit') NOT NULL,
        payment_status ENUM('pending', 'partial', 'completed', 'failed', 'cancelled') DEFAULT 'pending',
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        created_by INT,
        FOREIGN KEY (customer_id) REFERENCES customers(id),
        FOREIGN KEY (created_by) REFERENCES users(id)
    )",

    // Sale items
    "CREATE TABLE IF NOT EXISTS sale_items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        sale_id INT NOT NULL,
        product_id INT NOT NULL,
        quantity INT NOT NULL,
        unit_price DECIMAL(12,2) NOT NULL,
        total_price DECIMAL(12,2) NOT NULL,
        discount_amount DECIMAL(12,2) DEFAULT 0,
        FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products(id)
    )",

    // Purchase Orders
    "CREATE TABLE IF NOT EXISTS purchase_orders (
        id INT AUTO_INCREMENT PRIMARY KEY,
        po_number VARCHAR(50) UNIQUE,
        supplier_id INT NOT NULL,
        total_amount DECIMAL(12,2) NOT NULL,
        status ENUM('draft', 'pending', 'approved', 'received', 'partially_received', 'cancelled') DEFAULT 'draft',
        expected_date DATE,
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        created_by INT,
        approved_by INT,
        FOREIGN KEY (supplier_id) REFERENCES suppliers(id),
        FOREIGN KEY (created_by) REFERENCES users(id),
        FOREIGN KEY (approved_by) REFERENCES users(id)
    )",

    // Purchase order items
    "CREATE TABLE IF NOT EXISTS po_items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        po_id INT NOT NULL,
        product_id INT NOT NULL,
        quantity INT NOT NULL,
        received_quantity INT DEFAULT 0,
        unit_price DECIMAL(12,2) NOT NULL,
        total_price DECIMAL(12,2) NOT NULL,
        FOREIGN KEY (po_id) REFERENCES purchase_orders(id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products(id)
    )",

    // Financial transactions
    "CREATE TABLE IF NOT EXISTS transactions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        transaction_type ENUM('sale', 'purchase', 'payment', 'refund', 'expense') NOT NULL,
        reference_id INT,
        amount DECIMAL(12,2) NOT NULL,
        description TEXT,
        payment_method ENUM('cash', 'card', 'mobile_money', 'bank_transfer') NOT NULL,
        status ENUM('pending', 'completed', 'failed', 'cancelled') DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        created_by INT,
        FOREIGN KEY (created_by) REFERENCES users(id)
    )",

    // Reports table for storing generated reports
    "CREATE TABLE IF NOT EXISTS reports (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        type ENUM('sales', 'inventory', 'financial', 'customer', 'custom') NOT NULL,
        format ENUM('pdf', 'excel', 'csv') NOT NULL,
        file_path VARCHAR(500),
        generated_by INT,
        generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (generated_by) REFERENCES users(id)
    )"
];

// Create indexes for better performance
$indexes = [
    "CREATE INDEX idx_users_role ON users(role)",
    "CREATE INDEX idx_products_category ON products(category_id)",
    "CREATE INDEX idx_sales_customer ON sales(customer_id)",
    "CREATE INDEX idx_sales_date ON sales(created_at)",
    "CREATE INDEX idx_stock_movements_product ON stock_movements(product_id)",
    "CREATE INDEX idx_stock_movements_date ON stock_movements(created_at)"
];

// Create views for common queries
$views = [
    "CREATE VIEW IF NOT EXISTS v_active_products AS
    SELECT p.*, c.name as category_name, s.name as supplier_name
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    LEFT JOIN suppliers s ON p.supplier_id = s.id
    WHERE p.status = 'active'",
    
    "CREATE VIEW IF NOT EXISTS v_sales_summary AS
    SELECT 
        s.id,
        s.invoice_number,
        c.name as customer_name,
        s.subtotal,
        s.tax_amount,
        s.discount_amount,
        s.total_amount,
        s.payment_status,
        u.username as created_by,
        s.created_at
    FROM sales s
    LEFT JOIN customers c ON s.customer_id = c.id
    LEFT JOIN users u ON s.created_by = u.id",
    
    "CREATE VIEW IF NOT EXISTS v_inventory_status AS
    SELECT 
        p.id,
        p.name,
        p.sku,
        c.name as category_name,
        p.stock_quantity,
        p.minimum_stock,
        CASE 
            WHEN p.stock_quantity <= 0 THEN 'Out of Stock'
            WHEN p.stock_quantity <= p.minimum_stock THEN 'Low Stock'
            ELSE 'In Stock'
        END as stock_status
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    WHERE p.status = 'active'"
];

// Create tables
$success = true;
$errors = [];

echo "Creating tables...\n";

foreach ($tables as $table) {
    if ($conn->query($table) === FALSE) {
        $success = false;
        $errors[] = "Error creating table: " . $conn->error;
        echo "Error: " . $conn->error . "\n";
    } else {
        echo "Table created successfully\n";
    }
}

// Create indexes
echo "\nCreating indexes...\n";

foreach ($indexes as $index) {
    if ($conn->query($index) === FALSE) {
        $errors[] = "Error creating index: " . $conn->error;
        echo "Error: " . $conn->error . "\n";
    } else {
        echo "Index created successfully\n";
    }
}

// Create views
echo "\nCreating views...\n";

foreach ($views as $view) {
    if ($conn->query($view) === FALSE) {
        $errors[] = "Error creating view: " . $conn->error;
        echo "Error: " . $conn->error . "\n";
    } else {
        echo "View created successfully\n";
    }
}

// Insert default admin user
echo "\nInserting default admin user...\n";

$check_admin = "SELECT id FROM users WHERE username = 'admin'";
$result = $conn->query($check_admin);

if ($result->num_rows == 0) {
    // Default password is 'admin123' (hashed)
    $default_admin_password = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi';
    $insert_admin = "INSERT INTO users (username, password, email, role) VALUES ('admin', '$default_admin_password', 'admin@mobility.com', 'admin')";
    
    if ($conn->query($insert_admin) === FALSE) {
        $success = false;
        $errors[] = "Failed to create default admin user: " . $conn->error;
        echo "Error: " . $conn->error . "\n";
    } else {
        echo "Default admin user created successfully\n";
    }
}

// Insert default settings
echo "\nInserting default settings...\n";

$default_settings = [
    "INSERT IGNORE INTO settings (setting_key, setting_value, setting_type, description) VALUES 
    ('company_name', 'Mobility Inventory System', 'string', 'Company name displayed in the system'),
    ('currency', 'FRW', 'string', 'Default currency used in the system'),
    ('tax_rate', '18', 'number', 'Default tax rate percentage'),
    ('loyalty_points_ratio', '100', 'number', 'Amount spent to earn 1 loyalty point'),
    ('min_reorder_days', '7', 'number', 'Minimum days of stock for reorder alerts')"
];

foreach ($default_settings as $setting) {
    if ($conn->query($setting) === FALSE) {
        $success = false;
        $errors[] = "Failed to insert default setting: " . $conn->error;
        echo "Error: " . $conn->error . "\n";
    } else {
        echo "Default setting inserted successfully\n";
    }
}

// Return result
$response = [
    "success" => $success,
    "message" => $success ? "Multi-user database initialized successfully" : "Error initializing multi-user database",
    "errors" => $errors,
    "default_admin" => [
        "username" => "admin",
        "password" => "admin123",
        "email" => "admin@mobility.com"
    ]
];

echo json_encode($response, JSON_PRETTY_PRINT);

// Close connection
$conn->close();
?>