<?php
// Database Configuration for Mobility Inventory Management System

// Database configuration
$host = "localhost";
$username = "root";
$password = "";
$database = "emmy_db";

try {
    // Create connection
    $conn = new mysqli($host, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    // Set charset to handle special characters
    $conn->set_charset("utf8mb4");

} catch (Exception $e) {
    die("Database connection error: " . $e->getMessage());
}

// Include user functions
$userFunctionsPath = __DIR__ . '/user_functions.php';
if (file_exists($userFunctionsPath)) {
    include_once $userFunctionsPath;
}

// Include language functions
$languageFunctionsPath = __DIR__ . '/languages.php';
if (file_exists($languageFunctionsPath)) {
    include_once $languageFunctionsPath;
}

// Track if connection has been closed
$conn_closed = false;

// Function to safely close the database connection
function closeConnection() {
    global $conn, $conn_closed;
    // Check if connection exists and has not been closed yet
    if (isset($conn) && $conn instanceof mysqli && !$conn_closed) {
        $conn->close();
        $conn_closed = true;
    }
}

// Function to get the current system ID from session or default to 1
function getCurrentSystemId() {
    // In a real implementation, this would come from the user's session
    // For now, we'll default to 1 (the main system)
    return isset($_SESSION['system_id']) ? $_SESSION['system_id'] : 1;
}

// Function to get the current tenant ID from session
function getCurrentTenantId() {
    return isset($_SESSION['tenant_id']) ? $_SESSION['tenant_id'] : null;
}

// Function to add tenant filter to queries
function addTenantFilter($query, $tenant_field = 'tenant_id') {
    $tenant_id = getCurrentTenantId();
    if ($tenant_id) {
        // Add tenant filter to the query
        if (stripos($query, 'WHERE') !== false) {
            // If query already has WHERE clause, add AND condition
            $query = str_replace('WHERE', "WHERE {$tenant_field} = {$tenant_id} AND ", $query);
        } else {
            // If no WHERE clause, add WHERE condition
            $query .= " WHERE {$tenant_field} = {$tenant_id}";
        }
    }
    return $query;
}

// Enhanced function to add tenant filter with better validation
function addTenantFilterSecure($query, $tenant_field = 'tenant_id', $allowed_tables = []) {
    $tenant_id = getCurrentTenantId();
    
    // Validate tenant ID
    if (!$tenant_id || !is_numeric($tenant_id)) {
        throw new Exception("Invalid tenant ID");
    }
    
    // Extract table name from query for validation
    if (!empty($allowed_tables)) {
        $table_found = false;
        foreach ($allowed_tables as $table) {
            if (stripos($query, $table) !== false) {
                $table_found = true;
                break;
            }
        }
        
        if (!$table_found) {
            throw new Exception("Table not allowed for tenant filtering");
        }
    }
    
    // Add tenant filter to the query
    if (stripos($query, 'WHERE') !== false) {
        // If query already has WHERE clause, add AND condition
        $query = str_replace('WHERE', "WHERE {$tenant_field} = {$tenant_id} AND ", $query);
    } else {
        // If no WHERE clause, add WHERE condition
        $query .= " WHERE {$tenant_field} = {$tenant_id}";
    }
    
    return $query;
}

// Function to get the current user ID from session
function getCurrentUserId() {
    return isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
}

// Function to validate that a user belongs to the current tenant
function validateUserTenant($conn, $user_id) {
    $tenant_id = getCurrentTenantId();
    if (!$tenant_id) {
        return false;
    }
    
    $query = "SELECT id FROM users WHERE id = ? AND tenant_id = ?";
    $stmt = $conn->prepare($query);
    if ($stmt) {
        $stmt->bind_param("ii", $user_id, $tenant_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $valid = $result->num_rows > 0;
        $stmt->close();
        return $valid;
    }
    
    return false;
}

// Function to add tenant_id column to INSERT queries
function addTenantIdToInsertQuery($query, $tenant_id) {
    // This function adds tenant_id to INSERT queries
    if (stripos($query, 'INSERT INTO') !== false && $tenant_id) {
        // Extract table name
        preg_match('/INSERT INTO\s+([^\s\(]+)/i', $query, $matches);
        if (isset($matches[1])) {
            $table = $matches[1];
            
            // Check if tenant_id column exists in the table
            // For now, we'll assume it exists for tables that need it
            $tables_with_tenant = ['products', 'customers', 'sales', 'users', 'categories', 'suppliers'];
            if (in_array($table, $tables_with_tenant)) {
                // Add tenant_id to the column list
                $query = preg_replace('/INSERT INTO\s+' . $table . '\s*\(([^)]+)\)/i', 'INSERT INTO ' . $table . ' (tenant_id, $1)', $query);
                
                // Add tenant_id to the values list
                $query = preg_replace('/VALUES\s*\(([^)]+)\)/i', 'VALUES (?, $1)', $query);
            }
        }
    }
    return $query;
}
?>