<?php
// Multi-System Database Configuration
$host = "localhost";
$username = "root";
$password = "";
$database = "mobility_multi_db";

try {
    // Create connection
    $conn = new mysqli($host, $username, $password);

    // Check connection
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    // Select the database (it should already exist)
    $conn->select_db($database);

    // Set charset to handle special characters
    $conn->set_charset("utf8mb4");

} catch (Exception $e) {
    die("Database connection error: " . $e->getMessage());
}

// Track if connection has been closed
$conn_closed = false;

// Function to safely close the database connection
function closeConnection() {
    global $conn, $conn_closed;
    // Check if connection exists and has not been closed yet
    if (isset($conn) && $conn instanceof mysqli && !$conn_closed) {
        $conn->close();
        $conn_closed = true;
    }
}

// Function to get the current system ID from session or default to 1
function getCurrentSystemId() {
    // In a real implementation, this would come from the user's session
    // For now, we'll default to 1 (the main system)
    return isset($_SESSION['system_id']) ? $_SESSION['system_id'] : 1;
}

// Function to get the current user ID from session
function getCurrentUserId() {
    return isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
}
?>