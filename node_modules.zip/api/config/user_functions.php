<?php
/**
 * User functions for the inventory management system
 */

/**
 * Get current user's profile information
 * 
 * @param mysqli $conn Database connection
 * @param int $user_id User ID
 * @return array|null User profile data or null if not found
 */
function getCurrentUserProfile($conn, $user_id) {
    if (!$conn || !$user_id) {
        return null;
    }
    
    $query = "SELECT u.username, u.role, u.profile_picture, t.business_name FROM users u LEFT JOIN tenants t ON u.tenant_id = t.id WHERE u.id = ?";
    $stmt = $conn->prepare($query);
    
    if ($stmt) {
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $user_profile = $result->fetch_assoc();
        $stmt->close();
        return $user_profile;
    }
    
    return null;
}

/**
 * Get current user's profile picture URL
 * 
 * @param mysqli $conn Database connection
 * @param int $user_id User ID
 * @return string Profile picture URL or empty string
 */
function getCurrentUserProfilePicture($conn, $user_id) {
    $user_profile = getCurrentUserProfile($conn, $user_id);
    
    if ($user_profile && !empty($user_profile['profile_picture'])) {
        $profile_picture = $user_profile['profile_picture'];
        // Check if file exists and is readable
        if (file_exists($profile_picture) && is_readable($profile_picture)) {
            return $profile_picture;
        }
    }
    
    return ''; // Return empty string, caller will use default icon
}

/**
 * Get current tenant information
 * 
 * @param mysqli $conn Database connection
 * @return array|null Tenant data or null if not found
 */
function getCurrentTenantInfo($conn) {
    if (!isset($_SESSION['tenant_id']) || !$_SESSION['tenant_id']) {
        return null;
    }
    
    $query = "SELECT * FROM tenants WHERE id = ?";
    $stmt = $conn->prepare($query);
    
    if ($stmt) {
        $stmt->bind_param("i", $_SESSION['tenant_id']);
        $stmt->execute();
        $result = $stmt->get_result();
        $tenant_info = $result->fetch_assoc();
        $stmt->close();
        return $tenant_info;
    }
    
    return null;
}

/**
 * Check if user has a specific permission
 * 
 * @param mysqli $conn Database connection
 * @param int $user_id User ID
 * @param string $permission Permission name
 * @return bool True if user has permission, false otherwise
 */
function userHasPermission($conn, $user_id, $permission) {
    // Validate inputs
    if (!$conn || !$user_id || !$permission) {
        return false;
    }
    
    // Admin users have all permissions
    $role_query = "SELECT role FROM users WHERE id = ?";
    $role_stmt = $conn->prepare($role_query);
    $role_stmt->bind_param("i", $user_id);
    $role_stmt->execute();
    $role_result = $role_stmt->get_result();
    
    if ($role_result->num_rows > 0) {
        $user_role = $role_result->fetch_assoc()['role'];
        if ($user_role === 'admin') {
            $role_stmt->close();
            return true;
        }
    }
    $role_stmt->close();
    
    // Check specific permission
    $query = "SELECT up.id FROM user_permissions up 
              JOIN permissions p ON up.permission_id = p.id 
              WHERE up.user_id = ? AND p.name = ? AND up.granted = 1";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("is", $user_id, $permission);
    $stmt->execute();
    $result = $stmt->get_result();
    $has_permission = $result->num_rows > 0;
    $stmt->close();
    
    return $has_permission;
}

/**
 * Check if user has any of the specified permissions
 * 
 * @param mysqli $conn Database connection
 * @param int $user_id User ID
 * @param array $permissions Array of permission names
 * @return bool True if user has any of the permissions, false otherwise
 */
function userHasAnyPermission($conn, $user_id, $permissions) {
    // Validate inputs
    if (!$conn || !$user_id || !is_array($permissions) || empty($permissions)) {
        return false;
    }
    
    // Admin users have all permissions
    $role_query = "SELECT role FROM users WHERE id = ?";
    $role_stmt = $conn->prepare($role_query);
    $role_stmt->bind_param("i", $user_id);
    $role_stmt->execute();
    $role_result = $role_stmt->get_result();
    
    if ($role_result->num_rows > 0) {
        $user_role = $role_result->fetch_assoc()['role'];
        if ($user_role === 'admin') {
            $role_stmt->close();
            return true;
        }
    }
    $role_stmt->close();
    
    // Check if user has any of the specified permissions
    $placeholders = str_repeat('?,', count($permissions) - 1) . '?';
    $query = "SELECT up.id FROM user_permissions up 
              JOIN permissions p ON up.permission_id = p.id 
              WHERE up.user_id = ? AND p.name IN ({$placeholders}) AND up.granted = 1";
    
    $stmt = $conn->prepare($query);
    $types = str_repeat('s', count($permissions));
    $params = array_merge([$user_id], $permissions);
    $stmt->bind_param("i" . $types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    $has_permission = $result->num_rows > 0;
    $stmt->close();
    
    return $has_permission;
}

/**
 * Get all permissions for a user
 * 
 * @param mysqli $conn Database connection
 * @param int $user_id User ID
 * @return array List of permission names
 */
function getUserPermissions($conn, $user_id) {
    // Validate inputs
    if (!$conn || !$user_id) {
        return [];
    }
    
    // Admin users have all permissions
    $role_query = "SELECT role FROM users WHERE id = ?";
    $role_stmt = $conn->prepare($role_query);
    $role_stmt->bind_param("i", $user_id);
    $role_stmt->execute();
    $role_result = $role_stmt->get_result();
    
    if ($role_result->num_rows > 0) {
        $user_role = $role_result->fetch_assoc()['role'];
        if ($user_role === 'admin') {
            $role_stmt->close();
            // Return all permissions for admin
            $all_perms_query = "SELECT name FROM permissions";
            $all_perms_result = $conn->query($all_perms_query);
            $permissions = [];
            while ($row = $all_perms_result->fetch_assoc()) {
                $permissions[] = $row['name'];
            }
            return $permissions;
        }
    }
    $role_stmt->close();
    
    // Get specific permissions for non-admin users
    $query = "SELECT p.name FROM user_permissions up 
              JOIN permissions p ON up.permission_id = p.id 
              WHERE up.user_id = ? AND up.granted = 1";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $permissions = [];
    while ($row = $result->fetch_assoc()) {
        $permissions[] = $row['name'];
    }
    $stmt->close();
    
    return $permissions;
}

/**
 * Assign permissions to a user
 * 
 * @param mysqli $conn Database connection
 * @param int $user_id User ID
 * @param array $permissions Array of permission names to assign
 * @return bool True on success, false on failure
 */
function assignUserPermissions($conn, $user_id, $permissions) {
    // Validate inputs
    if (!$conn || !$user_id || !is_array($permissions)) {
        return false;
    }
    
    // First, remove all existing permissions for this user
    $delete_query = "DELETE FROM user_permissions WHERE user_id = ?";
    $delete_stmt = $conn->prepare($delete_query);
    $delete_stmt->bind_param("i", $user_id);
    $delete_stmt->execute();
    $delete_stmt->close();
    
    // Then add the new permissions
    foreach ($permissions as $permission_name) {
        // Validate permission name
        if (!is_string($permission_name) || empty($permission_name)) {
            continue;
        }
        
        // Get permission ID
        $perm_query = "SELECT id FROM permissions WHERE name = ?";
        $perm_stmt = $conn->prepare($perm_query);
        $perm_stmt->bind_param("s", $permission_name);
        $perm_stmt->execute();
        $perm_result = $perm_stmt->get_result();
        
        if ($perm_result->num_rows > 0) {
            $permission_id = $perm_result->fetch_assoc()['id'];
            
            // Insert the permission assignment
            $insert_query = "INSERT INTO user_permissions (user_id, permission_id, granted) VALUES (?, ?, 1)";
            $insert_stmt = $conn->prepare($insert_query);
            $insert_stmt->bind_param("ii", $user_id, $permission_id);
            $insert_stmt->execute();
            $insert_stmt->close();
        }
        $perm_stmt->close();
    }
    
    return true;
}

/**
 * Get user role
 * 
 * @param mysqli $conn Database connection
 * @param int $user_id User ID
 * @return string|null User role or null if not found
 */
function getUserRole($conn, $user_id) {
    if (!$conn || !$user_id) {
        return null;
    }
    
    $query = "SELECT role FROM users WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $role = $result->fetch_assoc()['role'];
        $stmt->close();
        return $role;
    }
    
    $stmt->close();
    return null;
}

/**
 * Check if user has a specific role
 * 
 * @param mysqli $conn Database connection
 * @param int $user_id User ID
 * @param string $role Role to check
 * @return bool True if user has the role, false otherwise
 */
function userHasRole($conn, $user_id, $role) {
    $user_role = getUserRole($conn, $user_id);
    return $user_role === $role;
}

/**
 * Get a setting value from the database
 *
 * @param mysqli $conn Database connection
 * @param string $setting_key Setting key
 * @return string|null Setting value or null if not found
 */
function getSetting($conn, $setting_key) {
    if (!$conn || !$setting_key) {
        return null;
    }
    
    $query = "SELECT setting_value FROM settings WHERE setting_key = ?";
    $stmt = $conn->prepare($query);
    
    if ($stmt) {
        $stmt->bind_param("s", $setting_key);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $setting = $result->fetch_assoc();
            $stmt->close();
            return $setting['setting_value'];
        }
        
        $stmt->close();
    }
    
    return null;
}

/**
 * Save a setting value to the database
 *
 * @param mysqli $conn Database connection
 * @param string $setting_key Setting key
 * @param string $setting_value Setting value
 * @param int $updated_by User ID who updated the setting
 * @return bool True on success, false on failure
 */
function saveSetting($conn, $setting_key, $setting_value, $updated_by = null) {
    if (!$conn || !$setting_key) {
        return false;
    }
    
    // Check if setting already exists
    $check_query = "SELECT id FROM settings WHERE setting_key = ?";
    $check_stmt = $conn->prepare($check_query);
    
    if ($check_stmt) {
        $check_stmt->bind_param("s", $setting_key);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        $setting_exists = $check_result->num_rows > 0;
        $check_stmt->close();
        
        if ($setting_exists) {
            // Update existing setting
            $update_query = "UPDATE settings SET setting_value = ?, updated_at = CURRENT_TIMESTAMP";
            
            // Add updated_by if provided
            if ($updated_by) {
                $update_query .= ", updated_by = ?";
            }
            
            $update_query .= " WHERE setting_key = ?";
            $update_stmt = $conn->prepare($update_query);
            
            if ($update_stmt) {
                if ($updated_by) {
                    $update_stmt->bind_param("ssi", $setting_value, $updated_by, $setting_key);
                } else {
                    $update_stmt->bind_param("ss", $setting_value, $setting_key);
                }
                
                $result = $update_stmt->execute();
                $update_stmt->close();
                return $result;
            }
        } else {
            // Insert new setting
            $insert_query = "INSERT INTO settings (setting_key, setting_value";
            
            // Add updated_by if provided
            if ($updated_by) {
                $insert_query .= ", updated_by";
            }
            
            $insert_query .= ") VALUES (?, ?";
            
            if ($updated_by) {
                $insert_query .= ", ?";
            }
            
            $insert_query .= ")";
            
            $insert_stmt = $conn->prepare($insert_query);
            
            if ($insert_stmt) {
                if ($updated_by) {
                    $insert_stmt->bind_param("ssi", $setting_key, $setting_value, $updated_by);
                } else {
                    $insert_stmt->bind_param("ss", $setting_key, $setting_value);
                }
                
                $result = $insert_stmt->execute();
                $insert_stmt->close();
                return $result;
            }
        }
    }
    
    return false;
}

/**
 * Get all email configuration settings
 *
 * @param mysqli $conn Database connection
 * @return array Email configuration settings
 */
function getEmailConfig($conn) {
    $email_config = [
        'smtp_host' => getSetting($conn, 'smtp_host') ?? 'smtp.example.com',
        'smtp_port' => getSetting($conn, 'smtp_port') ?? '587',
        'smtp_username' => getSetting($conn, 'smtp_username') ?? 'noreply@example.com',
        'smtp_password' => getSetting($conn, 'smtp_password') ?? 'password',
        'encryption' => getSetting($conn, 'encryption') ?? 'tls'
    ];
    
    return $email_config;
}

/**
 * Save email configuration settings
 *
 * @param mysqli $conn Database connection
 * @param array $email_config Email configuration settings
 * @param int $updated_by User ID who updated the settings
 * @return bool True on success, false on failure
 */
function saveEmailConfig($conn, $email_config, $updated_by = null) {
    $success = true;
    
    if (isset($email_config['smtp_host'])) {
        $success = $success && saveSetting($conn, 'smtp_host', $email_config['smtp_host'], $updated_by);
    }
    
    if (isset($email_config['smtp_port'])) {
        $success = $success && saveSetting($conn, 'smtp_port', $email_config['smtp_port'], $updated_by);
    }
    
    if (isset($email_config['smtp_username'])) {
        $success = $success && saveSetting($conn, 'smtp_username', $email_config['smtp_username'], $updated_by);
    }
    
    if (isset($email_config['smtp_password'])) {
        $success = $success && saveSetting($conn, 'smtp_password', $email_config['smtp_password'], $updated_by);
    }
    
    if (isset($email_config['encryption'])) {
        $success = $success && saveSetting($conn, 'encryption', $email_config['encryption'], $updated_by);
    }
    
    return $success;
}
?>