<?php
// Allow cross-origin requests
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'emmy_db');

// Connect to MySQL
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die(json_encode([
        "success" => false,
        "message" => "Connection failed: " . $conn->connect_error
    ]));
}

// Add balance column if it doesn't exist
$check_balance_column = "SHOW COLUMNS FROM customers LIKE 'balance'";
$result = $conn->query($check_balance_column);

if ($result->num_rows == 0) {
    $add_balance_column = "ALTER TABLE customers ADD COLUMN balance DECIMAL(10,2) DEFAULT 0";
    if ($conn->query($add_balance_column) === FALSE) {
        echo json_encode([
            "success" => false,
            "message" => "Error adding balance column: " . $conn->error
        ]);
        $conn->close();
        exit();
    }
}

echo json_encode([
    "success" => true,
    "message" => "Customers table updated successfully with balance column"
]);

$conn->close();
?>