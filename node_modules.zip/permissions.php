<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Check if user is admin
if ($_SESSION['role'] !== 'admin') {
    // Redirect to dashboard if not admin
    header("Location: dashboard.php");
    exit();
}

// Include database connection with robust path resolution
$rootPath = __DIR__;
$databasePath = $rootPath . '/api/config/database.php';

// If the direct path doesn't work, try alternative paths
if (!file_exists($databasePath)) {
    $databasePath = $rootPath . '/../api/config/database.php';
}

if (!file_exists($databasePath)) {
    $databasePath = $rootPath . '/../../api/config/database.php';
}

if (file_exists($databasePath)) {
    include_once $databasePath;
} else {
    die("Database configuration file not found");
}

// Include language functions
include_once 'api/config/languages.php';
include_once 'api/config/user_functions.php';

// Set language if specified
if (isset($_GET['lang'])) {
    setCurrentLanguage($_GET['lang']);
}

// Get current language
$current_lang = getCurrentLanguage();

$username = $_SESSION['username'] ?? 'User';
$role = $_SESSION['role'] ?? 'admin';

// Handle form submissions
$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'update_user_permissions':
                $user_id = $_POST['user_id'] ?? 0;
                $permissions = isset($_POST['permissions']) ? $_POST['permissions'] : [];
                
                if (is_numeric($user_id) && $user_id > 0) {
                    // Verify that the user belongs to the current tenant
                    $verify_query = "SELECT id FROM users WHERE id = ? AND tenant_id = ?";
                    $verify_stmt = $conn->prepare($verify_query);
                    if ($verify_stmt) {
                        $verify_stmt->bind_param("ii", $user_id, $_SESSION['tenant_id']);
                        $verify_stmt->execute();
                        $verify_result = $verify_stmt->get_result();
                        
                        if ($verify_result->num_rows > 0) {
                            // Update user permissions
                            if (assignUserPermissions($conn, $user_id, $permissions)) {
                                // Log the activity
                                $activity_query = "INSERT INTO activity_log (user_id, action_type, table_name, record_id, new_values) VALUES (?, 'update_permissions', 'users', ?, ?)";
                                $activity_stmt = $conn->prepare($activity_query);
                                if ($activity_stmt) {
                                    $new_values = json_encode(['permissions' => $permissions]);
                                    $activity_stmt->bind_param("iis", $_SESSION['user_id'], $user_id, $new_values);
                                    $activity_stmt->execute();
                                    $activity_stmt->close();
                                }
                                
                                $message = "User permissions updated successfully!";
                                $message_type = "success";
                            } else {
                                $message = "Error updating user permissions.";
                                $message_type = "error";
                            }
                        } else {
                            $message = "Invalid user.";
                            $message_type = "error";
                        }
                        $verify_stmt->close();
                    } else {
                        $message = "Database error: " . $conn->error;
                        $message_type = "error";
                    }
                } else {
                    $message = "Invalid user ID.";
                    $message_type = "error";
                }
                break;
        }
    }
}

// Fetch all permissions
$permissions = [];
$permissions_query = "SELECT id, name, description, module FROM permissions ORDER BY module, name";
$permissions_result = $conn->query($permissions_query);
if ($permissions_result) {
    while ($row = $permissions_result->fetch_assoc()) {
        $permissions[] = $row;
    }
}

// Group permissions by module for easier display
$grouped_permissions = [];
foreach ($permissions as $permission) {
    $module = $permission['module'] ?: 'General';
    if (!isset($grouped_permissions[$module])) {
        $grouped_permissions[$module] = [];
    }
    $grouped_permissions[$module][] = $permission;
}

// Fetch all users for permission management within the current tenant
$users = [];
$users_query = "SELECT id, username, role FROM users WHERE tenant_id = ? ORDER BY username";
$users_stmt = $conn->prepare($users_query);
if ($users_stmt) {
    $users_stmt->bind_param("i", $_SESSION['tenant_id']);
    $users_stmt->execute();
    $users_result = $users_stmt->get_result();
    if ($users_result) {
        while ($row = $users_result->fetch_assoc()) {
            $users[] = $row;
        }
    }
    $users_stmt->close();
}
?>

<!DOCTYPE html>
<html lang="<?php echo $current_lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Permissions Management - Complete Inventory Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Custom styles for permissions management */
        .permission-group {
            border-bottom: 1px solid #e5e7eb;
            padding-bottom: 1rem;
            margin-bottom: 1rem;
        }
        
        .permission-group:last-child {
            border-bottom: none;
            margin-bottom: 0;
        }
        
        .select-all-permissions {
            background-color: #eff6ff;
            padding: 0.25rem 0.5rem;
            border-radius: 0.375rem;
            font-size: 0.75rem;
        }
        
        .select-all-permissions:hover {
            background-color: #dbeafe;
        }
        
        /* Scrollbar styling for permissions container */
        .permissions-container::-webkit-scrollbar {
            width: 6px;
        }
        
        .permissions-container::-webkit-scrollbar-track {
            background: #f1f1f1;
        }
        
        .permissions-container::-webkit-scrollbar-thumb {
            background: #c5c5c5;
            border-radius: 3px;
        }
        
        .permissions-container::-webkit-scrollbar-thumb:hover {
            background: #a0a0a0;
        }
        
        /* Collapsible sections */
        .collapsible-header {
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.5rem;
            background-color: #f9fafb;
            border-radius: 0.375rem;
            margin-bottom: 0.5rem;
        }
        
        .collapsible-content {
            padding: 0.5rem;
        }
        
        /* Permission items */
        .permission-item {
            padding: 0.25rem 0;
        }
        
        /* Search box styling */
        .search-box {
            border: 1px solid #d1d5db;
            border-radius: 0.375rem;
            padding: 0.5rem;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>
    <div class="flex h-screen bg-gray-50">
        <!-- Sidebar -->
        <div class="w-64 bg-gradient-to-b from-green-700 to-green-900 shadow-lg">
            <div class="p-4 border-b border-green-600">
                <h1 class="text-xl font-bold text-white">IMS</h1>
                <p class="text-sm text-green-200">Inventory Management</p>
            </div>
            <nav class="mt-4">
                <a href="dashboard.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-tachometer-alt mr-3"></i>
                    <span><?php echo t('dashboard'); ?></span>
                </a>
                <a href="products.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-box mr-3"></i>
                    <span>Products</span>
                </a>
                <a href="categories.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-tags mr-3"></i>
                    <span>Categories</span>
                </a>
                <a href="purchases.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-shopping-cart mr-3"></i>
                    <span>Purchases</span>
                </a>
                <a href="expenses.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-file-invoice-dollar mr-3"></i>
                    <span>Expenses</span>
                </a>
                <a href="suppliers.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-truck mr-3"></i>
                    <span>Suppliers</span>
                </a>
                <a href="pos.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-cash-register mr-3"></i>
                    <span>Point of Sale</span>
                </a>
                <a href="stock-movements.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-exchange-alt mr-3"></i>
                    <span>Stock Movements</span>
                </a>
                <a href="customers.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-users mr-3"></i>
                    <span>Customers</span>
                </a>
                <a href="sales.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-shopping-cart mr-3"></i>
                    <span>Sales</span>
                </a>
                <a href="reports.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-chart-bar mr-3"></i>
                    <span><?php echo t('reports'); ?></span>
                </a>
                <a href="users.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-user mr-3"></i>
                    <span><?php echo t('users'); ?></span>
                </a>
                <a href="permissions.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-white bg-gradient-to-r from-green-500 to-green-600 border-l-4 border-green-300">
                    <i class="fas fa-user-shield mr-3"></i>
                    <span>Permissions</span>
                </a>
                <a href="settings.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-cog mr-3"></i>
                    <span><?php echo t('settings'); ?></span>
                </a>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="flex-1 flex flex-col overflow-hidden">
            <!-- Header -->
            <header class="flex items-center justify-between p-4 bg-gradient-to-r from-green-600 to-green-800 shadow">
                <h2 class="text-xl font-semibold text-white">Permissions Management</h2>
                <div class="flex items-center space-x-4">
                    <!-- Language Selector -->
                    <div class="relative">
                        <select onchange="window.location.href=this.value" class="bg-green-600 text-white rounded px-2 py-1 text-sm">
                            <option value="?lang=en" <?php echo ($current_lang == 'en') ? 'selected' : ''; ?>>English</option>
                            <option value="?lang=fr" <?php echo ($current_lang == 'fr') ? 'selected' : ''; ?>>Français</option>
                            <option value="?lang=rw" <?php echo ($current_lang == 'rw') ? 'selected' : ''; ?>>Kinyarwanda</option>
                        </select>
                    </div>
                    <!-- User Profile Dropdown -->
                    <div class="relative">
                        <button id="user-menu-button" class="flex items-center space-x-2 text-white focus:outline-none">
                            <?php 
                            $profile_picture = getCurrentUserProfilePicture($conn, $_SESSION['user_id']);
                            if (!empty($profile_picture)): ?>
                                <img src="<?php echo htmlspecialchars($profile_picture); ?>" alt="Profile" class="w-8 h-8 rounded-full object-cover">
                            <?php else: ?>
                                <div class="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center">
                                    <i class="fas fa-user text-white"></i>
                                </div>
                            <?php endif; ?>
                            <div class="text-left hidden md:block">
                                <p class="text-sm font-medium text-white"><?php echo htmlspecialchars($username); ?></p>
                                <p class="text-xs text-green-100 capitalize"><?php echo htmlspecialchars($role); ?></p>
                            </div>
                            <i class="fas fa-chevron-down text-green-200 text-xs"></i>
                        </button>
                        
                        <!-- Dropdown menu -->
                        <div id="user-dropdown" class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 hidden z-50">
                            <div class="px-4 py-2 border-b border-gray-200">
                                <p class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($username); ?></p>
                                <p class="text-xs text-gray-500 capitalize"><?php echo htmlspecialchars($role); ?></p>
                            </div>
                            <a href="profile.php?lang=<?php echo $current_lang; ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-user-circle mr-2"></i><?php echo t('profile'); ?>
                            </a>
                            <a href="settings.php?lang=<?php echo $current_lang; ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-cog mr-2"></i><?php echo t('settings'); ?>
                            </a>
                            <a href="logout.php?lang=<?php echo $current_lang; ?>" class="block px-4 py-2 text-sm text-red-600 hover:bg-gray-100">
                                <i class="fas fa-sign-out-alt mr-2"></i><?php echo t('logout'); ?>
                            </a>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Message Display -->
            <?php if ($message): ?>
                <div class="p-4 <?php echo $message_type === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'; ?>">
                    <div class="container mx-auto">
                        <?php echo htmlspecialchars($message); ?>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Permissions Content -->
            <main class="flex-1 overflow-y-auto p-6">
                <div class="bg-white rounded-lg shadow overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <h3 class="text-lg font-medium text-gray-800">User Permissions Management</h3>
                        <p class="text-sm text-gray-600 mt-1">Manage permissions for users in your organization</p>
                    </div>
                    <div class="p-6">
                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            <div>
                                <h4 class="text-md font-medium text-gray-700 mb-4">Select User</h4>
                                <form method="POST">
                                    <input type="hidden" name="action" value="update_user_permissions">
                                    <div class="mb-4">
                                        <select id="user-select" name="user_id" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
                                            <option value="">Select a user</option>
                                            <?php foreach ($users as $user): ?>
                                                <option value="<?php echo $user['id']; ?>">
                                                    <?php echo htmlspecialchars($user['username']); ?> (<?php echo htmlspecialchars($user['role']); ?>)
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </form>
                            </div>
                            
                            <div>
                                <h4 class="text-md font-medium text-gray-700 mb-4">Manage Permissions</h4>
                                <form method="POST" id="permissions-form">
                                    <input type="hidden" name="action" value="update_user_permissions">
                                    <input type="hidden" name="user_id" id="permissions-user-id">
                                    
                                    <div class="mb-4">
                                        <p class="text-sm text-gray-600 mb-3">Select the permissions you want to grant to this user. Admin users automatically have all permissions.</p>
                                        
                                        <!-- Permission Search -->
                                        <div class="search-box">
                                            <input type="text" id="permission-search" placeholder="Search permissions..." class="w-full p-2 border rounded">
                                        </div>
                                        
                                        <!-- Permission Groups -->
                                        <div class="border rounded-lg p-3 permissions-container max-h-96 overflow-y-auto">
                                            <?php foreach ($grouped_permissions as $module => $module_permissions): ?>
                                                <div class="permission-group">
                                                    <div class="collapsible-header">
                                                        <h4 class="font-medium text-gray-800 capitalize"><?php echo htmlspecialchars(str_replace('_', ' ', $module)); ?></h4>
                                                        <div class="flex items-center space-x-2">
                                                            <button type="button" class="text-xs text-green-600 select-all-permissions" data-module="<?php echo $module; ?>">
                                                                Select All
                                                            </button>
                                                            <i class="fas fa-chevron-down text-gray-500"></i>
                                                        </div>
                                                    </div>
                                                    <div class="collapsible-content">
                                                        <div class="grid grid-cols-1 gap-1">
                                                            <?php foreach ($module_permissions as $permission): ?>
                                                                <div class="permission-item flex items-center">
                                                                    <input type="checkbox" 
                                                                           id="perm_<?php echo $permission['id']; ?>" 
                                                                           name="permissions[]" 
                                                                           value="<?php echo $permission['name']; ?>"
                                                                           class="permission-checkbox rounded border-gray-300 text-green-600 shadow-sm focus:border-green-300 focus:ring focus:ring-green-200 focus:ring-opacity-50 permission-search-item"
                                                                           data-description="<?php echo strtolower(htmlspecialchars($permission['description'])); ?>"
                                                                           data-module="<?php echo $module; ?>">
                                                                    <label for="perm_<?php echo $permission['id']; ?>" class="ml-2 text-sm text-gray-700">
                                                                        <?php echo htmlspecialchars($permission['description']); ?>
                                                                        <span class="text-gray-500 text-xs block"><?php echo htmlspecialchars($permission['name']); ?></span>
                                                                    </label>
                                                                </div>
                                                            <?php endforeach; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                    
                                    <div class="mt-4">
                                        <button type="submit" class="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700">
                                            Update Permissions
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Permissions Legend -->
                <div class="bg-white rounded-lg shadow overflow-hidden mt-6">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <h3 class="text-lg font-medium text-gray-800">Permissions Overview</h3>
                    </div>
                    <div class="p-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            <?php foreach ($grouped_permissions as $module => $module_permissions): ?>
                                <div class="border rounded-lg p-4">
                                    <h4 class="font-medium text-gray-800 capitalize mb-2"><?php echo htmlspecialchars(str_replace('_', ' ', $module)); ?></h4>
                                    <ul class="text-sm text-gray-600 space-y-1">
                                        <?php foreach ($module_permissions as $permission): ?>
                                            <li class="flex items-start">
                                                <i class="fas fa-check-circle text-green-500 mt-1 mr-2 text-xs"></i>
                                                <div>
                                                    <span class="font-medium"><?php echo htmlspecialchars($permission['description']); ?></span>
                                                    <span class="block text-xs text-gray-500"><?php echo htmlspecialchars($permission['name']); ?></span>
                                                </div>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script>
        // JavaScript for permissions management
        document.addEventListener('DOMContentLoaded', function() {
            const userSelect = document.getElementById('user-select');
            const permissionsUserId = document.getElementById('permissions-user-id');
            const permissionsForm = document.getElementById('permissions-form');
            
            // When user is selected, load their permissions
            userSelect.addEventListener('change', function() {
                const userId = this.value;
                if (!userId) {
                    return;
                }
                
                // Set user ID in the form
                permissionsUserId.value = userId;
                
                // Uncheck all permissions first
                const permissionCheckboxes = document.querySelectorAll('.permission-checkbox');
                permissionCheckboxes.forEach(checkbox => {
                    checkbox.checked = false;
                });
                
                // Fetch user permissions and check the appropriate checkboxes
                fetch(`get_user_permissions.php?user_id=${userId}`)
                    .then(response => response.json())
                    .then(permissions => {
                        permissions.forEach(permission => {
                            const checkbox = document.querySelector(`input[name="permissions[]"][value="${permission}"]`);
                            if (checkbox) {
                                checkbox.checked = true;
                            }
                        });
                    })
                    .catch(error => console.error('Error fetching user permissions:', error));
            });
            
            // Collapsible sections
            document.querySelectorAll('.collapsible-header').forEach(header => {
                header.addEventListener('click', function() {
                    const content = this.nextElementSibling;
                    const icon = this.querySelector('i');
                    content.classList.toggle('hidden');
                    if (content.classList.contains('hidden')) {
                        icon.classList.remove('fa-chevron-up');
                        icon.classList.add('fa-chevron-down');
                    } else {
                        icon.classList.remove('fa-chevron-down');
                        icon.classList.add('fa-chevron-up');
                    }
                });
            });
            
            // Select all permissions for a module
            document.querySelectorAll('.select-all-permissions').forEach(button => {
                button.addEventListener('click', function(e) {
                    e.stopPropagation();
                    const module = this.getAttribute('data-module');
                    const checkboxes = document.querySelectorAll(`input.permission-checkbox[data-module="${module}"]`);
                    
                    // Check if all are currently selected
                    const allSelected = Array.from(checkboxes).every(checkbox => checkbox.checked);
                    
                    // Toggle selection
                    checkboxes.forEach(checkbox => {
                        checkbox.checked = !allSelected;
                    });
                });
            });
            
            // Permission search functionality
            const permissionSearch = document.getElementById('permission-search');
            if (permissionSearch) {
                permissionSearch.addEventListener('input', function() {
                    const searchTerm = this.value.toLowerCase();
                    const permissionItems = document.querySelectorAll('.permission-search-item');
                    
                    permissionItems.forEach(item => {
                        const description = item.getAttribute('data-description');
                        const module = item.getAttribute('data-module');
                        const moduleHeader = item.closest('.permission-group').querySelector('.collapsible-header h4');
                        const moduleName = moduleHeader.textContent.toLowerCase();
                        
                        if (searchTerm === '' || 
                            description.includes(searchTerm) || 
                            moduleName.includes(searchTerm)) {
                            item.closest('.permission-item').style.display = '';
                            // Show the parent module section
                            item.closest('.permission-group').style.display = '';
                        } else {
                            item.closest('.permission-item').style.display = 'none';
                        }
                    });
                    
                    // Hide modules with no matching permissions
                    document.querySelectorAll('.permission-group').forEach(group => {
                        const visibleItems = group.querySelectorAll('.permission-item:not([style*="display: none"])');
                        if (searchTerm !== '' && visibleItems.length === 0) {
                            group.style.display = 'none';
                        } else {
                            group.style.display = '';
                        }
                    });
                });
            }
            
            // User profile dropdown toggle
            const userMenuButton = document.getElementById('user-menu-button');
            const userDropdown = document.getElementById('user-dropdown');
            
            if (userMenuButton && userDropdown) {
                userMenuButton.addEventListener('click', function(e) {
                    e.stopPropagation();
                    userDropdown.classList.toggle('hidden');
                });
                
                // Close dropdown when clicking outside
                document.addEventListener('click', function() {
                    userDropdown.classList.add('hidden');
                });
                
                // Prevent closing when clicking inside dropdown
                userDropdown.addEventListener('click', function(e) {
                    e.stopPropagation();
                });
            }
        });
    </script>
</body>
</html>