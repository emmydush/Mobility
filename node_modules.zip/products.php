<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Include database connection with robust path resolution
$rootPath = __DIR__;
$databasePath = $rootPath . '/api/config/database.php';

// If the direct path doesn't work, try alternative paths
if (!file_exists($databasePath)) {
    $databasePath = $rootPath . '/../api/config/database.php';
}

if (!file_exists($databasePath)) {
    $databasePath = $rootPath . '/../../api/config/database.php';
}

if (file_exists($databasePath)) {
    include_once $databasePath;
} else {
    die("Database configuration file not found");
}

// Include language functions
include_once 'api/config/languages.php';

// Set language if specified
if (isset($_GET['lang'])) {
    setCurrentLanguage($_GET['lang']);
}

// Get current language
$current_lang = getCurrentLanguage();

$username = $_SESSION['username'] ?? 'User';
$role = $_SESSION['role'] ?? 'cashier';

// Handle form submissions
$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $name = $_POST['name'] ?? '';
                $sku = $_POST['sku'] ?? '';
                $barcode = $_POST['barcode'] ?? '';
                $category_id = $_POST['category_id'] ?? 0;
                $price = $_POST['price'] ?? 0;
                $cost_price = $_POST['cost_price'] ?? 0;
                $stock = $_POST['stock'] ?? 0;
                $expiry_date = $_POST['expiry_date'] ?? null;
                
                // Handle image upload
                $image_url = null;
                if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                    $upload_dir = 'product_images/';
                    // Create directory if it doesn't exist
                    if (!file_exists($upload_dir)) {
                        mkdir($upload_dir, 0777, true);
                    }
                    $file_name = uniqid() . '_' . basename($_FILES['image']['name']);
                    $target_file = $upload_dir . $file_name;
                    
                    // Check if image file is actual image
                    $check = getimagesize($_FILES['image']['tmp_name']);
                    if ($check !== false) {
                        // Move uploaded file
                        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                            $image_url = $target_file;
                        }
                    }
                }
                
                if (!empty($name) && !empty($sku) && !empty($category_id) && is_numeric($price) && is_numeric($cost_price) && is_numeric($stock)) {
                    if ($image_url) {
                        $query = "INSERT INTO products (tenant_id, name, sku, barcode, category_id, price, cost_price, stock_quantity, expiry_date, image_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                        $stmt = $conn->prepare($query);
                        if ($stmt) {
                            $stmt->bind_param("issssidsss", $_SESSION['tenant_id'], $name, $sku, $barcode, $category_id, $price, $cost_price, $stock, $expiry_date, $image_url);
                        }
                    } else {
                        $query = "INSERT INTO products (tenant_id, name, sku, barcode, category_id, price, cost_price, stock_quantity, expiry_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                        $stmt = $conn->prepare($query);
                        if ($stmt) {
                            $stmt->bind_param("issssidss", $_SESSION['tenant_id'], $name, $sku, $barcode, $category_id, $price, $cost_price, $stock, $expiry_date);
                        }
                    }
                    
                    if ($stmt && $stmt->execute()) {
                        $message = "Product added successfully!";
                        $message_type = "success";
                    } else {
                        $message = "Error adding product: " . $conn->error;
                        $message_type = "error";
                    }
                    if ($stmt) {
                        $stmt->close();
                    }
                } else {
                    $message = "All fields are required and price/cost/stock must be numeric.";
                    $message_type = "error";
                }
                break;
                
            case 'edit':
                $id = $_POST['id'] ?? 0;
                $name = $_POST['name'] ?? '';
                $sku = $_POST['sku'] ?? '';
                $barcode = $_POST['barcode'] ?? '';
                $category_id = $_POST['category_id'] ?? 0;
                $price = $_POST['price'] ?? 0;
                $cost_price = $_POST['cost_price'] ?? 0;
                $stock = $_POST['stock'] ?? 0;
                $expiry_date = $_POST['expiry_date'] ?? null;
                
                // Handle image upload
                $image_url = null;
                if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                    $upload_dir = 'product_images/';
                    // Create directory if it doesn't exist
                    if (!file_exists($upload_dir)) {
                        mkdir($upload_dir, 0777, true);
                    }
                    $file_name = uniqid() . '_' . basename($_FILES['image']['name']);
                    $target_file = $upload_dir . $file_name;
                    
                    // Check if image file is actual image
                    $check = getimagesize($_FILES['image']['tmp_name']);
                    if ($check !== false) {
                        // Move uploaded file
                        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                            $image_url = $target_file;
                        }
                    }
                }
                
                if (!empty($id) && !empty($name) && !empty($sku) && !empty($category_id) && is_numeric($price) && is_numeric($cost_price) && is_numeric($stock)) {
                    // First verify that the product belongs to the current tenant
                    $verify_query = "SELECT id FROM products WHERE id = ? AND tenant_id = ?";
                    $verify_stmt = $conn->prepare($verify_query);
                    $verify_stmt->bind_param("ii", $id, $_SESSION['tenant_id']);
                    $verify_stmt->execute();
                    $verify_result = $verify_stmt->get_result();
                    
                    if ($verify_result->num_rows > 0) {
                        if ($image_url) {
                            // Update with new image
                            $query = "UPDATE products SET name = ?, sku = ?, barcode = ?, category_id = ?, price = ?, cost_price = ?, stock_quantity = ?, expiry_date = ?, image_url = ? WHERE id = ? AND tenant_id = ?";
                            $stmt = $conn->prepare($query);
                            if ($stmt) {
                                $stmt->bind_param("ssssidsssii", $name, $sku, $barcode, $category_id, $price, $cost_price, $stock, $expiry_date, $image_url, $id, $_SESSION['tenant_id']);
                            }
                        } else {
                            // Update without changing image
                            $query = "UPDATE products SET name = ?, sku = ?, barcode = ?, category_id = ?, price = ?, cost_price = ?, stock_quantity = ?, expiry_date = ? WHERE id = ? AND tenant_id = ?";
                            $stmt = $conn->prepare($query);
                            if ($stmt) {
                                $stmt->bind_param("ssssidssii", $name, $sku, $barcode, $category_id, $price, $cost_price, $stock, $expiry_date, $id, $_SESSION['tenant_id']);
                            }
                        }
                        
                        if ($stmt && $stmt->execute()) {
                            $message = "Product updated successfully!";
                            $message_type = "success";
                        } else {
                            $message = "Error updating product: " . $conn->error;
                            $message_type = "error";
                        }
                        if ($stmt) {
                            $stmt->close();
                        }
                    } else {
                        $message = "Product not found or you don't have permission to edit it.";
                        $message_type = "error";
                    }
                    $verify_stmt->close();
                } else {
                    $message = "All fields are required and price/cost/stock must be numeric.";
                    $message_type = "error";
                }
                break;
                
            case 'delete':
                $id = $_POST['id'] ?? 0;
                if (is_numeric($id) && $id > 0) {
                    // First verify that the product belongs to the current tenant
                    $verify_query = "SELECT id FROM products WHERE id = ? AND tenant_id = ?";
                    $verify_stmt = $conn->prepare($verify_query);
                    $verify_stmt->bind_param("ii", $id, $_SESSION['tenant_id']);
                    $verify_stmt->execute();
                    $verify_result = $verify_stmt->get_result();
                    
                    if ($verify_result->num_rows > 0) {
                        $query = "DELETE FROM products WHERE id = ? AND tenant_id = ?";
                        $stmt = $conn->prepare($query);
                        if ($stmt) {
                            $stmt->bind_param("ii", $id, $_SESSION['tenant_id']);
                            if ($stmt->execute()) {
                                $message = "Product deleted successfully!";
                                $message_type = "success";
                            } else {
                                $message = "Error deleting product: " . $conn->error;
                                $message_type = "error";
                            }
                            $stmt->close();
                        } else {
                            $message = "Database error: " . $conn->error;
                            $message_type = "error";
                        }
                    } else {
                        $message = "Product not found or you don't have permission to delete it.";
                        $message_type = "error";
                    }
                    $verify_stmt->close();
                } else {
                    $message = "Invalid product ID.";
                    $message_type = "error";
                }
                break;
        }
    }
}

// Fetch all products with category names for the current tenant
$products = array();
$query = "SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.tenant_id = ? ORDER BY p.name";
$stmt = $conn->prepare($query);
if ($stmt) {
    $stmt->bind_param("i", $_SESSION['tenant_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
    $stmt->close();
}

// Fetch all categories for the dropdown
$categories_list = array();
$category_query = "SELECT id, name FROM categories ORDER BY name";
$category_stmt = $conn->prepare($category_query);
if ($category_stmt) {
    $category_stmt->execute();
    $category_result = $category_stmt->get_result();
    while ($row = $category_result->fetch_assoc()) {
        $categories_list[] = $row;
    }
    $category_stmt->close();
}
?>

<!DOCTYPE html>
<html lang="<?php echo $current_lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products - Complete Inventory Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Add QuaggaJS for barcode scanning -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/quagga/0.12.1/quagga.min.js"></script>
    <style>
        /* Responsive Design */
        @media (max-width: 1024px) {
            .sidebar {
                width: 16rem;
            }
            
            .table-container {
                overflow-x: auto;
            }
        }
        
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease-in-out;
                position: fixed;
                height: 100vh;
                z-index: 1000;
            }
            
            .sidebar.open {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .menu-toggle {
                display: block;
            }
            
            .header-title {
                font-size: 1.25rem;
            }
            
            .user-info {
                display: none;
            }
            
            .mobile-user-info {
                display: block;
            }
            
            .action-buttons {
                flex-direction: column;
                gap: 0.5rem;
            }
            
            .add-product-btn {
                width: 100%;
                text-align: center;
            }
            
            .form-grid {
                grid-template-columns: 1fr;
            }
            
            .modal-content {
                width: 95%;
                margin: 5% auto;
                padding: 15px;
            }
        }
        
        @media (max-width: 480px) {
            .header-actions {
                flex-direction: column;
                gap: 0.5rem;
            }
            
            .language-selector select {
                padding: 0.25rem 0.5rem;
                font-size: 0.75rem;
            }
            
            .add-product-btn {
                padding: 0.25rem 0.5rem;
                font-size: 0.75rem;
            }
            
            .table th, .table td {
                padding: 0.5rem;
                font-size: 0.75rem;
            }
            
            .action-buttons {
                flex-direction: column;
                gap: 0.25rem;
            }
            
            .action-buttons button, .action-buttons form {
                padding: 0.25rem 0.5rem;
                font-size: 0.75rem;
            }
            
            .form-group input,
            .form-group select,
            .form-group textarea {
                padding: 0.4rem;
                font-size: 0.875rem;
            }
            
            .form-buttons {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
                padding: 0.5rem;
                font-size: 0.875rem;
            }
        }
        
        .menu-toggle {
            display: none;
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
        }
        
        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999;
        }
        
        .mobile-user-info {
            display: none;
        }
    </style>
</head>
<body>
    <!-- Mobile menu toggle button and overlay -->
    <button class="menu-toggle fixed top-4 left-4 z-50" id="menu-toggle">
        <i class="fas fa-bars"></i>
    </button>
    
    <div class="overlay" id="overlay"></div>
    
    <div class="flex h-screen bg-gray-50">
        <!-- Sidebar -->
        <div class="w-64 bg-gradient-to-b from-green-700 to-green-900 shadow-lg">
            <div class="p-4 border-b border-green-600">
                <h1 class="text-xl font-bold text-white">IMS</h1>
                <p class="text-sm text-green-200">Inventory Management</p>
            </div>
            <nav class="mt-4">
                <a href="dashboard.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-tachometer-alt mr-3"></i>
                    <span><?php echo t('dashboard'); ?></span>
                </a>
                <a href="products.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-white bg-gradient-to-r from-green-500 to-green-600 border-l-4 border-green-300">
                    <i class="fas fa-box mr-3"></i>
                    <span>Products</span>
                </a>
                <a href="categories.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-tags mr-3"></i>
                    <span>Categories</span>
                </a>
                <a href="purchases.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-shopping-cart mr-3"></i>
                    <span>Purchases</span>
                </a>
                <a href="expenses.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-file-invoice-dollar mr-3"></i>
                    <span>Expenses</span>
                </a>
                <a href="suppliers.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-truck mr-3"></i>
                    <span>Suppliers</span>
                </a>
                <a href="pos.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-cash-register mr-3"></i>
                    <span>Point of Sale</span>
                </a>
                <a href="stock-movements.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-exchange-alt mr-3"></i>
                    <span>Stock Movements</span>
                </a>
                <a href="customers.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-users mr-3"></i>
                    <span>Customers</span>
                </a>
                <a href="sales.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-shopping-cart mr-3"></i>
                    <span>Sales</span>
                </a>
                <a href="reports.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-chart-bar mr-3"></i>
                    <span><?php echo t('reports'); ?></span>
                </a>
                <a href="advanced_reports.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-chart-line mr-3"></i>
                    <span>Advanced Reports</span>
                </a>
                <a href="users.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-user mr-3"></i>
                    <span><?php echo t('users'); ?></span>
                </a>
                <a href="settings.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-cog mr-3"></i>
                    <span><?php echo t('settings'); ?></span>
                </a>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="flex-1 flex flex-col overflow-hidden">
            <!-- Header -->
            <header class="flex items-center justify-between p-4 bg-gradient-to-r from-green-600 to-green-800 shadow">
                <h2 class="text-xl font-semibold text-white">Product Management</h2>
                <div class="flex items-center space-x-4">
                    <!-- Language Selector -->
                    <div class="relative">
                        <select onchange="window.location.href=this.value" class="bg-green-600 text-white rounded px-2 py-1 text-sm">
                            <option value="?lang=en" <?php echo ($current_lang == 'en') ? 'selected' : ''; ?>>English</option>
                            <option value="?lang=fr" <?php echo ($current_lang == 'fr') ? 'selected' : ''; ?>>Français</option>
                            <option value="?lang=rw" <?php echo ($current_lang == 'rw') ? 'selected' : ''; ?>>Kinyarwanda</option>
                        </select>
                    </div>
                    <button id="add-product-btn" class="px-4 py-2 text-sm bg-white text-green-600 rounded hover:bg-green-50 transition duration-200">
                        <i class="fas fa-plus mr-1"></i> Add Product
                    </button>
                    <!-- User Profile Dropdown -->
                    <div class="relative">
                        <button id="user-menu-button" class="flex items-center space-x-2 text-white focus:outline-none">
                            <div class="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center">
                                <i class="fas fa-user text-white"></i>
                            </div>
                            <div class="text-left hidden md:block">
                                <p class="text-sm font-medium text-white"><?php echo htmlspecialchars($username); ?></p>
                                <p class="text-xs text-green-100 capitalize"><?php echo htmlspecialchars($role); ?></p>
                            </div>
                            <i class="fas fa-chevron-down text-green-200 text-xs"></i>
                        </button>
                        
                        <!-- Dropdown menu -->
                        <div id="user-dropdown" class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 hidden z-50">
                            <div class="px-4 py-2 border-b border-gray-200">
                                <p class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($username); ?></p>
                                <p class="text-xs text-gray-500 capitalize"><?php echo htmlspecialchars($role); ?></p>
                            </div>
                            <a href="profile.php?lang=<?php echo $current_lang; ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-user-circle mr-2"></i><?php echo t('profile'); ?>
                            </a>
                            <a href="settings.php?lang=<?php echo $current_lang; ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-cog mr-2"></i><?php echo t('settings'); ?>
                            </a>
                            <a href="logout.php?lang=<?php echo $current_lang; ?>" class="block px-4 py-2 text-sm text-red-600 hover:bg-gray-100">
                                <i class="fas fa-sign-out-alt mr-2"></i><?php echo t('logout'); ?>
                            </a>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Message Display -->
            <?php if ($message): ?>
                <div class="p-4 <?php echo $message_type === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'; ?>">
                    <div class="container mx-auto">
                        <?php echo htmlspecialchars($message); ?>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Products Content -->
            <main class="flex-1 overflow-y-auto p-6">
                <div class="bg-white rounded-lg shadow overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <h3 class="text-lg font-medium text-gray-800">Product List</h3>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Image</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">SKU</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cost Price</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stock</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Expiry Date</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php if (count($products) > 0): ?>
                                    <?php foreach ($products as $product): ?>
                                        <tr>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <?php if (!empty($product['image_url']) && file_exists($product['image_url'])): ?>
                                                    <img src="<?php echo htmlspecialchars($product['image_url']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="h-12 w-12 object-cover rounded">
                                                <?php else: ?>
                                                    <div class="h-12 w-12 bg-gray-200 rounded flex items-center justify-center">
                                                        <i class="fas fa-image text-gray-500"></i>
                                                    </div>
                                                <?php endif; ?>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($product['name']); ?></div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                <?php echo htmlspecialchars($product['sku']); ?>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                <?php echo htmlspecialchars($product['category_name']); ?>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                FRW<?php echo number_format($product['price'], 2); ?>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                FRW<?php echo number_format($product['cost_price'], 2); ?>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                <?php echo $product['stock_quantity']; ?>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                <?php echo $product['expiry_date'] ? date('M j, Y', strtotime($product['expiry_date'])) : 'N/A'; ?>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                                <button class="view-product-btn text-green-600 hover:text-green-900 mr-3" 
                                                    data-id="<?php echo $product['id']; ?>"
                                                    data-name="<?php echo htmlspecialchars($product['name']); ?>"
                                                    data-sku="<?php echo htmlspecialchars($product['sku']); ?>"
                                                    data-category="<?php echo htmlspecialchars($product['category_name']); ?>"
                                                    data-price="<?php echo $product['price']; ?>"
                                                    data-cost-price="<?php echo $product['cost_price']; ?>"
                                                    data-stock="<?php echo $product['stock_quantity']; ?>"
                                                    data-expiry-date="<?php echo $product['expiry_date']; ?>"
                                                    data-image-url="<?php echo htmlspecialchars($product['image_url'] ?? ''); ?>">
                                                    View
                                                </button>
                                                <button class="edit-product-btn text-green-600 hover:text-green-900 mr-3" 
                                                    data-id="<?php echo $product['id']; ?>"
                                                    data-name="<?php echo htmlspecialchars($product['name']); ?>"
                                                    data-sku="<?php echo htmlspecialchars($product['sku']); ?>"
                                                    data-category-id="<?php echo $product['category_id']; ?>"
                                                    data-price="<?php echo $product['price']; ?>"
                                                    data-cost-price="<?php echo $product['cost_price']; ?>"
                                                    data-stock="<?php echo $product['stock_quantity']; ?>"
                                                    data-expiry-date="<?php echo $product['expiry_date']; ?>"
                                                    data-image-url="<?php echo htmlspecialchars($product['image_url'] ?? ''); ?>">
                                                    Edit
                                                </button>
                                                <form method="POST" class="inline" onsubmit="return confirm('Are you sure you want to delete this product?')">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="id" value="<?php echo $product['id']; ?>">
                                                    <button type="submit" class="text-red-600 hover:text-red-900">Delete</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8" class="px-6 py-4 text-center text-gray-500">
                                            No products found
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Add Product Modal -->
    <div id="product-modal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full z-50">
        <div class="relative top-10 mx-auto p-4 border w-full max-w-2xl shadow-lg rounded-md bg-white">
            <div class="mt-3">
                <h3 class="text-lg font-medium text-gray-900 mb-4" id="modal-title">Add Product</h3>
                <form method="POST" class="space-y-4" enctype="multipart/form-data">
                    <input type="hidden" name="action" value="add" id="form-action">
                    <input type="hidden" name="id" value="" id="product-id">
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-gray-700 text-sm font-bold mb-1" for="product-name">
                                Name *
                            </label>
                            <input type="text" id="product-name" name="name" required
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline text-sm">
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 text-sm font-bold mb-1" for="product-sku">
                                SKU *
                            </label>
                            <input type="text" id="product-sku" name="sku" required
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline text-sm">
                        </div>
                                        
                        <div>
                            <label class="block text-gray-700 text-sm font-bold mb-1" for="product-barcode">
                                Barcode
                            </label>
                            <div class="flex">
                                <input type="text" id="product-barcode" name="barcode"
                                    class="shadow appearance-none border rounded-l w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline text-sm">
                                <button type="button" id="scan-barcode-btn" class="bg-green-500 hover:bg-green-700 text-white py-2 px-4 rounded-r">
                                    <i class="fas fa-barcode"></i> Scan
                                </button>
                            </div>
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 text-sm font-bold mb-1" for="product-category">
                                Category *
                            </label>
                            <select id="product-category" name="category_id" required
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline text-sm">
                                <option value="">Select Category</option>
                                <?php foreach ($categories_list as $category): ?>
                                    <option value="<?php echo $category['id']; ?>"><?php echo htmlspecialchars($category['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 text-sm font-bold mb-1" for="product-stock">
                                Current Stock *
                            </label>
                            <input type="number" id="product-stock" name="stock" required
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline text-sm">
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 text-sm font-bold mb-1" for="product-price">
                                Selling Price *
                            </label>
                            <input type="number" id="product-price" name="price" step="0.01" required
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline text-sm">
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 text-sm font-bold mb-1" for="product-cost-price">
                                Cost Price *
                            </label>
                            <input type="number" id="product-cost-price" name="cost_price" step="0.01" required
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline text-sm">
                        </div>
                        
                        <div class="md:col-span-2">
                            <label class="block text-gray-700 text-sm font-bold mb-1" for="product-expiry-date">
                                Expiry Date (Optional)
                            </label>
                            <input type="date" id="product-expiry-date" name="expiry_date"
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline text-sm">
                        </div>
                        
                        <div class="md:col-span-2">
                            <label class="block text-gray-700 text-sm font-bold mb-1" for="product-image">
                                Product Image (Optional)
                            </label>
                            <input type="file" id="product-image" name="image" accept="image/*"
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline text-sm">
                            <p class="text-gray-500 text-xs mt-1">JPEG, PNG, GIF (Max 2MB)</p>
                            <div id="image-preview-container" class="mt-2">
                                <img id="image-preview" src="" alt="Image Preview" class="max-h-32 hidden">
                                <div id="current-image-container" class="mt-2 hidden">
                                    <p class="text-gray-600 text-sm">Current Image:</p>
                                    <img id="current-image" src="" alt="Current Image" class="max-h-32">
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="flex items-center justify-between mt-6">
                        <button type="button" id="cancel-product-btn"
                            class="px-4 py-2 text-sm bg-gray-600 text-white rounded hover:bg-gray-700">
                            Cancel
                        </button>
                        <button type="submit"
                            class="px-4 py-2 text-sm bg-green-600 text-white rounded hover:bg-green-700">
                            Save Product
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- View Product Modal -->
    <div id="view-product-modal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full z-50">
        <div class="relative top-10 mx-auto p-4 border w-full max-w-2xl shadow-lg rounded-md bg-white">
            <div class="mt-3">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-lg font-medium text-gray-900">Product Details</h3>
                    <button id="close-view-modal" class="text-gray-500 hover:text-gray-700">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <div class="mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-1">Product Image</label>
                            <div id="view-image-container">
                                <img id="view-image" src="" alt="Product Image" class="max-h-48 mx-auto">
                                <div id="view-no-image" class="h-48 flex items-center justify-center bg-gray-100 rounded hidden">
                                    <i class="fas fa-image text-gray-400 text-4xl"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div>
                        <div class="mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-1">Product Name</label>
                            <div id="view-name" class="text-gray-900"></div>
                        </div>
                        
                        <div class="mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-1">SKU</label>
                            <div id="view-sku" class="text-gray-900"></div>
                        </div>
                        
                        <div class="mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-1">Category</label>
                            <div id="view-category" class="text-gray-900"></div>
                        </div>
                        
                        <div class="mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-1">Selling Price</label>
                            <div id="view-price" class="text-gray-900"></div>
                        </div>
                        
                        <div class="mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-1">Cost Price</label>
                            <div id="view-cost-price" class="text-gray-900"></div>
                        </div>
                        
                        <div class="mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-1">Stock Quantity</label>
                            <div id="view-stock" class="text-gray-900"></div>
                        </div>
                        
                        <div class="mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-1">Expiry Date</label>
                            <div id="view-expiry-date" class="text-gray-900"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Barcode Scanner Modal -->
    <div id="barcode-scanner-modal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full z-50">
        <div class="relative top-20 mx-auto p-4 border w-full max-w-md shadow-lg rounded-md bg-white">
            <div class="mt-3">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-lg font-medium text-gray-900">Scan Barcode</h3>
                    <button id="close-scanner-modal" class="text-gray-500 hover:text-gray-700">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                
                <div class="mb-4">
                    <div id="scanner-container" class="w-full h-64 bg-black relative overflow-hidden rounded">
                        <video id="scanner-video" class="w-full h-full object-cover"></video>
                        <div class="absolute inset-0 flex items-center justify-center">
                            <div class="border-2 border-green-500 w-48 h-32"></div>
                        </div>
                        <canvas id="scanner-canvas" class="absolute top-0 left-0 w-full h-full"></canvas>
                    </div>
                    <div id="scanner-status" class="text-center mt-2 text-gray-600">Point camera at barcode</div>
                </div>
                
                <div class="flex justify-between">
                    <button id="cancel-scanner-btn" class="px-4 py-2 text-sm bg-gray-600 text-white rounded hover:bg-gray-700">
                        Cancel
                    </button>
                    <button id="manual-barcode-btn" class="px-4 py-2 text-sm bg-green-600 text-white rounded hover:bg-green-700">
                        Enter Manually
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Simple JavaScript for modal functionality
        document.addEventListener('DOMContentLoaded', function() {
            const modal = document.getElementById('product-modal');
            const viewModal = document.getElementById('view-product-modal');
            const addProductBtn = document.getElementById('add-product-btn');
            const cancelBtn = document.getElementById('cancel-product-btn');
            const closeViewModalBtn = document.getElementById('close-view-modal');
            const formAction = document.getElementById('form-action');
            const modalTitle = document.getElementById('modal-title');
            
            addProductBtn.addEventListener('click', function() {
                // Reset form for adding new product
                document.querySelector('form').reset();
                formAction.value = 'add';
                document.getElementById('product-id').value = '';
                modalTitle.textContent = 'Add Product';
                // Hide image previews
                document.getElementById('image-preview').classList.add('hidden');
                document.getElementById('current-image-container').classList.add('hidden');
                modal.classList.remove('hidden');
            });
            
            cancelBtn.addEventListener('click', function() {
                modal.classList.add('hidden');
            });
            
            closeViewModalBtn.addEventListener('click', function() {
                viewModal.classList.add('hidden');
            });
            
            // Close modal when clicking outside
            window.addEventListener('click', function(event) {
                if (event.target === modal) {
                    modal.classList.add('hidden');
                }
                if (event.target === viewModal) {
                    viewModal.classList.add('hidden');
                }
            });
            
            // Image preview functionality
            document.getElementById('product-image').addEventListener('change', function(e) {
                const file = e.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        const preview = document.getElementById('image-preview');
                        preview.src = e.target.result;
                        preview.classList.remove('hidden');
                    }
                    reader.readAsDataURL(file);
                }
            });
            
            // View product functionality
            const viewButtons = document.querySelectorAll('.view-product-btn');
            viewButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const name = this.getAttribute('data-name');
                    const sku = this.getAttribute('data-sku');
                    const category = this.getAttribute('data-category');
                    const price = this.getAttribute('data-price');
                    const costPrice = this.getAttribute('data-cost-price');
                    const stock = this.getAttribute('data-stock');
                    const expiryDate = this.getAttribute('data-expiry-date');
                    const imageUrl = this.getAttribute('data-image-url');
                    
                    // Populate view modal with product data
                    document.getElementById('view-name').textContent = name;
                    document.getElementById('view-sku').textContent = sku;
                    document.getElementById('view-category').textContent = category;
                    document.getElementById('view-price').textContent = 'FRW' + parseFloat(price).toFixed(2);
                    document.getElementById('view-cost-price').textContent = 'FRW' + parseFloat(costPrice).toFixed(2);
                    document.getElementById('view-stock').textContent = stock;
                    document.getElementById('view-expiry-date').textContent = expiryDate ? new Date(expiryDate).toLocaleDateString() : 'N/A';
                    
                    // Handle image display
                    const viewImage = document.getElementById('view-image');
                    const viewNoImage = document.getElementById('view-no-image');
                    
                    if (imageUrl && imageUrl.trim() !== '') {
                        viewImage.src = imageUrl;
                        viewImage.classList.remove('hidden');
                        viewNoImage.classList.add('hidden');
                    } else {
                        viewImage.classList.add('hidden');
                        viewNoImage.classList.remove('hidden');
                    }
                    
                    // Show view modal
                    viewModal.classList.remove('hidden');
                });
            });
            
            // Edit product functionality
            const editButtons = document.querySelectorAll('.edit-product-btn');
            editButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const id = this.getAttribute('data-id');
                    const name = this.getAttribute('data-name');
                    const sku = this.getAttribute('data-sku');
                    const categoryId = this.getAttribute('data-category-id');
                    const price = this.getAttribute('data-price');
                    const costPrice = this.getAttribute('data-cost-price');
                    const stock = this.getAttribute('data-stock');
                    const expiryDate = this.getAttribute('data-expiry-date');
                    const imageUrl = this.getAttribute('data-image-url');
                    
                    // Populate form with existing data
                    document.getElementById('product-id').value = id;
                    document.getElementById('product-name').value = name;
                    document.getElementById('product-sku').value = sku;
                    document.getElementById('product-category').value = categoryId;
                    document.getElementById('product-price').value = price;
                    document.getElementById('product-cost-price').value = costPrice;
                    document.getElementById('product-stock').value = stock;
                    document.getElementById('product-expiry-date').value = expiryDate;
                    
                    // Handle image display
                    const imagePreview = document.getElementById('image-preview');
                    const currentImageContainer = document.getElementById('current-image-container');
                    const currentImage = document.getElementById('current-image');
                    
                    // Hide preview and current image
                    imagePreview.classList.add('hidden');
                    currentImageContainer.classList.add('hidden');
                    
                    // Show current image if exists
                    if (imageUrl && imageUrl.trim() !== '') {
                        currentImage.src = imageUrl;
                        currentImageContainer.classList.remove('hidden');
                    }
                    
                    // Change form to edit mode
                    formAction.value = 'edit';
                    modalTitle.textContent = 'Edit Product';
                    modal.classList.remove('hidden');
                });
            });
            
            // User profile dropdown toggle
            const userMenuButton = document.getElementById('user-menu-button');
            const userDropdown = document.getElementById('user-dropdown');
            
            if (userMenuButton && userDropdown) {
                userMenuButton.addEventListener('click', function(e) {
                    e.stopPropagation();
                    userDropdown.classList.toggle('hidden');
                });
                
                // Close dropdown when clicking outside
                document.addEventListener('click', function() {
                    userDropdown.classList.add('hidden');
                });
                
                // Prevent closing when clicking inside dropdown
                userDropdown.addEventListener('click', function(e) {
                    e.stopPropagation();
                });
            }
            
            // Barcode scanner functionality
            const scanBarcodeBtn = document.getElementById('scan-barcode-btn');
            const scannerModal = document.getElementById('barcode-scanner-modal');
            const closeScannerModalBtn = document.getElementById('close-scanner-modal');
            const cancelScannerBtn = document.getElementById('cancel-scanner-btn');
            const manualBarcodeBtn = document.getElementById('manual-barcode-btn');
            const scannerVideo = document.getElementById('scanner-video');
            const scannerStatus = document.getElementById('scanner-status');
            const barcodeInput = document.getElementById('product-barcode');
            const scannerCanvas = document.getElementById('scanner-canvas');
            const scannerContext = scannerCanvas.getContext('2d');
            
            let stream = null;
            let isScanning = false;
            
            if (scanBarcodeBtn) {
                scanBarcodeBtn.addEventListener('click', function() {
                    scannerModal.classList.remove('hidden');
                    startScanner();
                });
            }
            
            if (closeScannerModalBtn) {
                closeScannerModalBtn.addEventListener('click', function() {
                    stopScanner();
                    scannerModal.classList.add('hidden');
                });
            }
            
            if (cancelScannerBtn) {
                cancelScannerBtn.addEventListener('click', function() {
                    stopScanner();
                    scannerModal.classList.add('hidden');
                });
            }
            
            if (manualBarcodeBtn) {
                manualBarcodeBtn.addEventListener('click', function() {
                    stopScanner();
                    scannerModal.classList.add('hidden');
                    // Focus on barcode input for manual entry
                    barcodeInput.focus();
                });
            }
            
            // Close scanner modal when clicking outside
            window.addEventListener('click', function(event) {
                if (event.target === scannerModal) {
                    stopScanner();
                    scannerModal.classList.add('hidden');
                }
            });
            
            function startScanner() {
                if (isScanning) return;
                
                if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
                    navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } })
                        .then(function(mediaStream) {
                            stream = mediaStream;
                            scannerVideo.srcObject = mediaStream;
                            scannerVideo.play();
                            scannerStatus.textContent = 'Scanning... Point camera at barcode';
                            isScanning = true;
                            
                            // Initialize QuaggaJS for barcode scanning
                            initQuagga();
                        })
                        .catch(function(err) {
                            console.error('Error accessing camera:', err);
                            scannerStatus.textContent = 'Error accessing camera: ' + err.name;
                        });
                } else {
                    scannerStatus.textContent = 'Camera not supported in this browser';
                }
            }
            
            function initQuagga() {
                if (!isScanning) return;
                
                Quagga.init({
                    inputStream: {
                        name: "Live",
                        type: "LiveStream",
                        target: document.querySelector("#scanner-container"),
                        constraints: {
                            width: 640,
                            height: 480,
                            facingMode: "environment"
                        }
                    },
                    decoder: {
                        readers: [
                            "code_128_reader",
                            "ean_reader",
                            "ean_8_reader",
                            "code_39_reader",
                            "code_39_vin_reader",
                            "codabar_reader",
                            "upc_reader",
                            "upc_e_reader",
                            "i2of5_reader"
                        ]
                    }
                }, function(err) {
                    if (err) {
                        console.error('Error initializing Quagga:', err);
                        scannerStatus.textContent = 'Error initializing scanner: ' + err;
                        return;
                    }
                    
                    Quagga.start();
                    scannerStatus.textContent = 'Scanner ready. Point camera at barcode.';
                });
                
                // Set up result handling
                Quagga.onDetected(function(result) {
                    if (result && result.codeResult && result.codeResult.code) {
                        const barcode = result.codeResult.code;
                        barcodeInput.value = barcode;
                        scannerStatus.textContent = 'Barcode detected: ' + barcode;
                        
                        // Stop scanning and close modal after successful scan
                        stopScanner();
                        setTimeout(function() {
                            scannerModal.classList.add('hidden');
                        }, 1500);
                    }
                });
                
                // Draw scanner visualization
                Quagga.onProcessed(function(result) {
                    const drawingCtx = scannerContext;
                    const canvas = scannerCanvas;
                    
                    if (result) {
                        if (result.boxes) {
                            drawingCtx.clearRect(0, 0, canvas.width, canvas.height);
                            result.boxes.filter(function(box) {
                                return box !== result.box;
                            }).forEach(function(box) {
                                Quagga.ImageDebug.drawPath(box, {x: 0, y: 1}, drawingCtx, {color: "green", lineWidth: 2});
                            });
                        }
                        
                        if (result.box) {
                            Quagga.ImageDebug.drawPath(result.box, {x: 0, y: 1}, drawingCtx, {color: "#00F", lineWidth: 2});
                        }
                        
                        if (result.codeResult && result.codeResult.code) {
                            Quagga.ImageDebug.drawPath(result.line, {x: 'x', y: 'y'}, drawingCtx, {color: 'red', lineWidth: 3});
                        }
                    }
                });
            }
            
            function stopScanner() {
                if (stream) {
                    const tracks = stream.getTracks();
                    tracks.forEach(track => track.stop());
                    stream = null;
                }
                
                if (isScanning) {
                    Quagga.stop();
                    isScanning = false;
                }
                
                scannerVideo.srcObject = null;
                scannerContext.clearRect(0, 0, scannerCanvas.width, scannerCanvas.height);
            }
            
            // Simulate barcode scanning for demonstration
            function simulateBarcodeScan() {
                // In a real implementation, you would use a library like QuaggaJS to detect barcodes
                // This is just a simulation for demonstration purposes
                setTimeout(function() {
                    // Only simulate if scanner is still active
                    if (stream && !scannerModal.classList.contains('hidden')) {
                        // Generate a random barcode for simulation
                        const simulatedBarcode = 'SIM' + Math.floor(Math.random() * 1000000000);
                        barcodeInput.value = simulatedBarcode;
                        scannerStatus.textContent = 'Barcode detected: ' + simulatedBarcode;
                        stopScanner();
                        setTimeout(function() {
                            scannerModal.classList.add('hidden');
                        }, 1500);
                    }
                }, 3000);
            }
        });
        
        // Toggle mobile menu
        document.getElementById('menu-toggle').addEventListener('click', function() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('overlay');
            
            sidebar.classList.toggle('open');
            overlay.style.display = sidebar.classList.contains('open') ? 'block' : 'none';
        });
        
        // Close mobile menu when clicking on overlay
        document.getElementById('overlay').addEventListener('click', function() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('overlay');
            
            sidebar.classList.remove('open');
            overlay.style.display = 'none';
        });
        
        // User dropdown toggle
        document.getElementById('user-menu-button').addEventListener('click', function() {
            const dropdown = document.getElementById('user-dropdown');
            dropdown.classList.toggle('hidden');
        });
        
        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            const dropdown = document.getElementById('user-dropdown');
            const button = document.getElementById('user-menu-button');
            
            if (!button.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.classList.add('hidden');
            }
        });
    </script>
</body>
</html>