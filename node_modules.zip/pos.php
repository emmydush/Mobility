<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Include database connection with robust path resolution
$rootPath = __DIR__;
$databasePath = $rootPath . '/api/config/database.php';

// If the direct path doesn't work, try alternative paths
if (!file_exists($databasePath)) {
    $databasePath = $rootPath . '/../api/config/database.php';
}

if (!file_exists($databasePath)) {
    $databasePath = $rootPath . '/../../api/config/database.php';
}

if (file_exists($databasePath)) {
    include_once $databasePath;
} else {
    die("Database configuration file not found");
}

// Include language functions
include_once 'api/config/languages.php';

// Set language if specified
if (isset($_GET['lang'])) {
    setCurrentLanguage($_GET['lang']);
}

// Get current language
$current_lang = getCurrentLanguage();

// Check if user has a tenant assigned
if (!isset($_SESSION['tenant_id']) || !$_SESSION['tenant_id']) {
    die("No business account assigned to your user. Please contact support.");
}

// Function to generate invoice number
function generateInvoiceNumber($conn, $tenant_id) {
    $prefix = "INV-" . date("Ymd");
    $query = "SELECT COUNT(*) as count FROM sales WHERE invoice_number LIKE ? AND tenant_id = ?";
    $stmt = $conn->prepare($query);
    if ($stmt) {
        $search = $prefix . "%";
        $stmt->bind_param("si", $search, $tenant_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $count = $row['count'] + 1;
        $stmt->close();
        return $prefix . "-" . str_pad($count, 4, "0", STR_PAD_LEFT);
    }
    return $prefix . "-0001";
}

// Generate invoice number for display
$invoice_number = generateInvoiceNumber($conn, $_SESSION['tenant_id']);

$username = $_SESSION['username'] ?? 'User';
$role = $_SESSION['role'] ?? 'cashier';

// Handle form submissions
$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'process_sale') {
        $customer_id = $_POST['customer_id'] ?? null;
        $cart_items = json_decode($_POST['cart_items'], true);
        $payment_method = $_POST['payment_method'] ?? 'cash';
        $amount_paid = floatval($_POST['amount_paid'] ?? 0);
        
        // Enable error reporting for debugging
        ini_set('display_errors', 1);
        error_reporting(E_ALL);
        
        if (!empty($cart_items) && is_array($cart_items)) {
            // Begin transaction
            $conn->begin_transaction();
            
            try {
                // Validate customer_id if provided (with tenant filtering)
                if ($customer_id !== null && $customer_id !== '') {
                    $customer_check_query = "SELECT id FROM customers WHERE id = ? AND tenant_id = ?";
                    $customer_check_stmt = $conn->prepare($customer_check_query);
                    if ($customer_check_stmt) {
                        $customer_check_stmt->bind_param("ii", $customer_id, $_SESSION['tenant_id']);
                        $customer_check_stmt->execute();
                        $customer_result = $customer_check_stmt->get_result();
                        if ($customer_result->num_rows === 0) {
                            // Customer ID doesn't exist or doesn't belong to this tenant, set to null
                            $customer_id = null;
                        }
                        $customer_check_stmt->close();
                    }
                } else {
                    // Ensure customer_id is null if empty string or not provided
                    $customer_id = null;
                }
                
                // Calculate totals
                $subtotal = 0;
                foreach ($cart_items as $item) {
                    $subtotal += $item['price'] * $item['quantity'];
                }
                
                // Get tax rate from settings (0% for now)
                $tax_rate = 0;
                $tax_amount = $subtotal * $tax_rate;
                $total_amount = $subtotal + $tax_amount;
                $amount_due = $total_amount - $amount_paid;
                
                // Generate invoice number
                $invoice_number = 'INV-' . date('Ymd') . '-' . rand(1000, 9999);
                
                // Insert sale record with tenant_id
                if ($customer_id !== null) {
                    $sale_query = "INSERT INTO sales (tenant_id, invoice_number, customer_id, subtotal, tax_amount, discount_amount, total_amount, amount_paid, amount_due, payment_method, payment_status, created_by) VALUES (?, ?, ?, ?, ?, 0, ?, ?, ?, ?, 'completed', ?)";
                    $sale_stmt = $conn->prepare($sale_query);
                    if ($sale_stmt === false) {
                        throw new Exception("Error preparing sale statement: " . $conn->error);
                    }
                    $sale_stmt->bind_param("issidddssi", $_SESSION['tenant_id'], $invoice_number, $customer_id, $subtotal, $tax_amount, $total_amount, $amount_paid, $amount_due, $payment_method, $_SESSION['user_id']);
                } else {
                    $sale_query = "INSERT INTO sales (tenant_id, invoice_number, subtotal, tax_amount, discount_amount, total_amount, amount_paid, amount_due, payment_method, payment_status, created_by) VALUES (?, ?, ?, ?, 0, ?, ?, ?, ?, 'completed', ?)";
                    $sale_stmt = $conn->prepare($sale_query);
                    if ($sale_stmt === false) {
                        throw new Exception("Error preparing sale statement: " . $conn->error);
                    }
                    $sale_stmt->bind_param("issdddssi", $_SESSION['tenant_id'], $invoice_number, $subtotal, $tax_amount, $total_amount, $amount_paid, $amount_due, $payment_method, $_SESSION['user_id']);
                }
                
                if ($sale_stmt->execute()) {
                    $sale_id = $conn->insert_id;
                    
                    // Process each cart item
                    foreach ($cart_items as $item) {
                        $product_id = $item['id'];
                        $quantity = $item['quantity'];
                        $unit_price = $item['price'];
                        $total_price = $unit_price * $quantity;
                        
                        // Insert sale item
                        $item_query = "INSERT INTO sale_items (sale_id, product_id, quantity, unit_price, total_price) VALUES (?, ?, ?, ?, ?)";
                        $item_stmt = $conn->prepare($item_query);
                        
                        if ($item_stmt === false) {
                            throw new Exception("Error preparing sale item statement: " . $conn->error);
                        }
                        
                        $item_stmt->bind_param("iiidd", $sale_id, $product_id, $quantity, $unit_price, $total_price);
                        
                        if (!$item_stmt->execute()) {
                            throw new Exception("Error adding sale item: " . $item_stmt->error);
                        }
                        $item_stmt->close();
                        
                        // Update product stock with tenant filtering
                        $update_query = "UPDATE products SET stock_quantity = stock_quantity - ? WHERE id = ? AND tenant_id = ?";
                        $update_stmt = $conn->prepare($update_query);
                        
                        if ($update_stmt === false) {
                            throw new Exception("Error preparing update statement: " . $conn->error);
                        }
                        
                        $update_stmt->bind_param("iii", $quantity, $product_id, $_SESSION['tenant_id']);
                        
                        if (!$update_stmt->execute()) {
                            throw new Exception("Error updating product stock: " . $update_stmt->error);
                        }
                        $update_stmt->close();
                    }
                    
                    // If customer exists, update loyalty points with tenant filtering
                    if ($customer_id) {
                        $points_earned = floor($total_amount / 100); // 1 point per 100 units
                        $customer_update_query = "UPDATE customers SET loyalty_points = loyalty_points + ?, total_purchases = total_purchases + ? WHERE id = ? AND tenant_id = ?";
                        $customer_update_stmt = $conn->prepare($customer_update_query);
                        
                        if ($customer_update_stmt) {
                            $customer_update_stmt->bind_param("idii", $points_earned, $total_amount, $customer_id, $_SESSION['tenant_id']);
                            $customer_update_stmt->execute();
                            $customer_update_stmt->close();
                        }
                    }
                    
                    $conn->commit();
                    $message = "Sale completed successfully! Invoice: " . $invoice_number;
                    $message_type = "success";
                } else {
                    throw new Exception("Error creating sale record: " . $sale_stmt->error);
                }
                $sale_stmt->close();
            } catch (Exception $e) {
                $conn->rollback();
                $message = "Error processing sale: " . $e->getMessage();
                $message_type = "error";
                // Log the error for debugging
                error_log("POS Sale Error: " . $e->getMessage());
            }
        } else {
            $message = "Cart is empty. Please add items before processing.";
            $message_type = "error";
        }
        
        // Return JSON response for AJAX requests
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            header('Content-Type: application/json');
            echo json_encode(['status' => $message_type, 'message' => $message]);
            exit;
        }
    }
}

// Fetch all products for the POS (for current tenant only)
$products = array();
$product_query = "SELECT id, name, selling_price, stock_quantity, image_url, barcode FROM products WHERE stock_quantity > 0 AND tenant_id = ? ORDER BY name";
$product_stmt = $conn->prepare($product_query);
if ($product_stmt) {
    $product_stmt->bind_param("i", $_SESSION['tenant_id']);
    $product_stmt->execute();
    $product_result = $product_stmt->get_result();
    while ($row = $product_result->fetch_assoc()) {
        $products[] = $row;
    }
    $product_stmt->close();
}

// Fetch all customers for the POS (for current tenant only)
$customers = array();
$customer_query = "SELECT id, name, email, phone FROM customers WHERE status = 'active' AND tenant_id = ? ORDER BY name";
$customer_stmt = $conn->prepare($customer_query);
if ($customer_stmt) {
    $customer_stmt->bind_param("i", $_SESSION['tenant_id']);
    $customer_stmt->execute();
    $customer_result = $customer_stmt->get_result();
    while ($row = $customer_result->fetch_assoc()) {
        $customers[] = $row;
    }
    $customer_stmt->close();
}
?>

<!DOCTYPE html>
<html lang="<?php echo $current_lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Point of Sale - Complete Inventory Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .product-grid {
            max-height: 500px;
            overflow-y: auto;
        }
        .cart-item {
            transition: background-color 0.2s;
        }
        .cart-item:hover {
            background-color: #f3f4f6;
        }
        #barcode-input {
            font-size: 1.2em;
            padding: 0.5rem 1rem;
        }
        #barcode-input:focus {
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.5);
        }
        #scan-region {
            box-shadow: inset 0 0 0 1000px rgba(0, 0, 0, 0.5);
        }
        #scanner-video {
            transform: scaleX(-1); /* Mirror the video */
        }
        
        /* Product card animations */
        .product-item {
            transition: all 0.3s ease;
            transform: translateY(0);
            opacity: 1;
        }
        
        .product-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }
        
        .product-item.added-to-cart {
            animation: pulse 0.5s ease-in-out;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
        
        /* Fade in animation for product grid */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .product-item {
            animation: fadeInUp 0.3s ease forwards;
        }
        
        /* Staggered animation delays */
        .product-item:nth-child(1) { animation-delay: 0.1s; }
        .product-item:nth-child(2) { animation-delay: 0.2s; }
        .product-item:nth-child(3) { animation-delay: 0.3s; }
        .product-item:nth-child(4) { animation-delay: 0.4s; }
        .product-item:nth-child(5) { animation-delay: 0.5s; }
        .product-item:nth-child(6) { animation-delay: 0.6s; }
        .product-item:nth-child(7) { animation-delay: 0.7s; }
        .product-item:nth-child(8) { animation-delay: 0.8s; }
        .product-item:nth-child(9) { animation-delay: 0.9s; }
        .product-item:nth-child(10) { animation-delay: 1.0s; }
        .product-item:nth-child(11) { animation-delay: 1.1s; }
        .product-item:nth-child(12) { animation-delay: 1.2s; }
        
        /* Continuous scanning mode indicator */
        .scanning-mode-active {
            background-color: #10B981;
            color: white;
            padding: 0.25rem 0.5rem;
            border-radius: 0.25rem;
            font-size: 0.75rem;
            margin-left: 0.5rem;
        }
    </style>
    
    <!-- Include QuaggaJS for barcode scanning -->
    <script src="https://unpkg.com/quagga@0.12.1/dist/quagga.min.js"></script>
</head>
<body>
    <div class="flex h-screen bg-gray-50">
        <!-- Sidebar -->
        <div class="w-64 bg-gradient-to-b from-green-700 to-green-900 shadow-lg">
            <div class="p-4 border-b border-green-600">
                <h1 class="text-xl font-bold text-white">IMS</h1>
                <p class="text-sm text-green-200">Inventory Management</p>
            </div>
            <nav class="mt-4">
                <a href="dashboard.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-tachometer-alt mr-3"></i>
                    <span><?php echo t('dashboard'); ?></span>
                </a>
                <a href="products.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-box mr-3"></i>
                    <span>Products</span>
                </a>
                <a href="categories.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-tags mr-3"></i>
                    <span>Categories</span>
                </a>
                <a href="purchases.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-shopping-cart mr-3"></i>
                    <span>Purchases</span>
                </a>
                <a href="expenses.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-file-invoice-dollar mr-3"></i>
                    <span>Expenses</span>
                </a>
                <a href="suppliers.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-truck mr-3"></i>
                    <span>Suppliers</span>
                </a>
                <a href="pos.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-white bg-gradient-to-r from-green-500 to-green-600 border-l-4 border-green-300">
                    <i class="fas fa-cash-register mr-3"></i>
                    <span>Point of Sale</span>
                </a>
                <a href="stock-movements.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-exchange-alt mr-3"></i>
                    <span>Stock Movements</span>
                </a>
                <a href="customers.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-users mr-3"></i>
                    <span>Customers</span>
                </a>
                <a href="sales.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-receipt mr-3"></i>
                    <span>Sales</span>
                </a>
                <a href="reports.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-chart-bar mr-3"></i>
                    <span><?php echo t('reports'); ?></span>
                </a>
                <a href="advanced_reports.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-chart-line mr-3"></i>
                    <span>Advanced Reports</span>
                </a>
                <a href="users.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-user mr-3"></i>
                    <span><?php echo t('users'); ?></span>
                </a>
                <a href="settings.php?lang=<?php echo $current_lang; ?>" class="flex items-center px-4 py-3 text-green-100 hover:bg-green-800 hover:text-white transition duration-200">
                    <i class="fas fa-cog mr-3"></i>
                    <span><?php echo t('settings'); ?></span>
                </a>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="flex-1 flex flex-col overflow-hidden">
            <!-- Header -->
            <header class="flex items-center justify-between p-4 bg-gradient-to-r from-green-600 to-green-800 shadow">
                <h2 class="text-xl font-semibold text-white">Point of Sale</h2>
                <div class="flex items-center space-x-4">
                    <!-- Language Selector -->
                    <div class="relative">
                        <select onchange="window.location.href=this.value" class="bg-green-600 text-white rounded px-2 py-1 text-sm">
                            <option value="?lang=en" <?php echo ($current_lang == 'en') ? 'selected' : ''; ?>>English</option>
                            <option value="?lang=fr" <?php echo ($current_lang == 'fr') ? 'selected' : ''; ?>>Français</option>
                            <option value="?lang=rw" <?php echo ($current_lang == 'rw') ? 'selected' : ''; ?>>Kinyarwanda</option>
                        </select>
                    </div>
                    <!-- User Profile Dropdown -->
                    <div class="relative">
                        <button id="user-menu-button" class="flex items-center space-x-2 text-white focus:outline-none">
                            <div class="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center">
                                <i class="fas fa-user text-white"></i>
                            </div>
                            <div class="text-left hidden md:block">
                                <p class="text-sm font-medium text-white"><?php echo htmlspecialchars($username); ?></p>
                                <p class="text-xs text-green-100 capitalize"><?php echo htmlspecialchars($role); ?></p>
                            </div>
                            <i class="fas fa-chevron-down text-green-200 text-xs"></i>
                        </button>
                        
                        <!-- Dropdown menu -->
                        <div id="user-dropdown" class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 hidden z-50">
                            <div class="px-4 py-2 border-b border-gray-200">
                                <p class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($username); ?></p>
                                <p class="text-xs text-gray-500 capitalize"><?php echo htmlspecialchars($role); ?></p>
                            </div>
                            <a href="profile.php?lang=<?php echo $current_lang; ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-user-circle mr-2"></i><?php echo t('profile'); ?>
                            </a>
                            <a href="logout.php?lang=<?php echo $current_lang; ?>" class="block px-4 py-2 text-sm text-red-600 hover:bg-gray-100">
                                <i class="fas fa-sign-out-alt mr-2"></i><?php echo t('logout'); ?>
                            </a>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Message Display -->
            <?php if ($message): ?>
                <div class="p-4 <?php echo $message_type === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'; ?>">
                    <div class="container mx-auto">
                        <?php echo htmlspecialchars($message); ?>
                    </div>
                </div>
            <?php endif; ?>

            <!-- POS Content -->
            <main class="flex-1 overflow-y-auto p-4">
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <!-- Product Selection -->
                    <div class="lg:col-span-2">
                        <div class="bg-white rounded-lg shadow p-4">
                            <h3 class="text-lg font-medium text-gray-800 mb-4">Products</h3>
                            
                            <!-- Barcode Scanner Input -->
                            <div class="mb-4">
                                <label class="block text-gray-700 text-sm font-bold mb-1">Scan Barcode</label>
                                <div class="flex">
                                    <input type="text" id="barcode-input" placeholder="Scan barcode or enter manually" 
                                        class="flex-1 px-4 py-2 border rounded-l-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                                    <button id="add-by-barcode" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-r-lg">
                                        <i class="fas fa-barcode"></i> Add
                                    </button>
                                    <button id="camera-scan-btn" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-r-lg ml-2">
                                        <i class="fas fa-camera"></i> Camera Scan
                                    </button>
                                    <button id="continuous-scan-btn" class="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-r-lg ml-2">
                                        <i class="fas fa-sync-alt"></i> Continuous
                                    </button>
                                </div>
                                <div id="scanning-mode-indicator" class="mt-2 text-sm text-gray-600 hidden">
                                    <span>Continuous scanning mode is active. Camera will remain open until you turn it off.</span>
                                </div>
                            </div>
                            
                            <!-- Camera Scanner Modal -->
                            <div id="camera-scanner-modal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full z-50">
                                <div class="relative top-20 mx-auto p-5 border w-11/12 max-w-3xl shadow-lg rounded-md bg-white">
                                    <div class="mt-3">
                                        <div class="flex justify-between items-center mb-4">
                                            <h3 class="text-lg font-medium text-gray-900">Camera Barcode Scanner</h3>
                                            <button id="close-camera-modal" class="text-gray-500 hover:text-gray-700">
                                                <i class="fas fa-times"></i>
                                            </button>
                                        </div>
                                        
                                        <div class="flex flex-col items-center">
                                            <div class="w-full max-w-md">
                                                <div id="scanner-container" class="relative">
                                                    <video id="scanner-video" class="w-full h-64 object-cover rounded-lg"></video>
                                                    <div id="scan-region" class="absolute inset-0 border-4 border-green-500 rounded-lg flex items-center justify-center">
                                                        <div class="text-white text-center">
                                                            <i class="fas fa-barcode text-4xl mb-2"></i>
                                                            <p>Position barcode in frame</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div id="scanner-result" class="mt-4 p-3 bg-gray-100 rounded-lg hidden">
                                                    <p class="font-medium">Scanned Barcode:</p>
                                                    <p id="scanned-barcode" class="text-lg font-bold"></p>
                                                    <button id="use-scanned-barcode" class="mt-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded">
                                                        Add to Cart
                                                    </button>
                                                </div>
                                                
                                                <div id="scanner-error" class="mt-4 p-3 bg-red-100 text-red-700 rounded-lg hidden">
                                                    <p id="error-message"></p>
                                                </div>
                                                
                                                <!-- Continuous scanning controls -->
                                                <div id="continuous-controls" class="mt-4 flex items-center justify-between hidden">
                                                    <div class="flex items-center">
                                                        <span class="mr-2 text-sm">Continuous Mode:</span>
                                                        <div class="relative inline-block w-12 h-6">
                                                            <input type="checkbox" id="continuous-toggle" class="opacity-0 w-0 h-0">
                                                            <label for="continuous-toggle" class="absolute cursor-pointer top-0 left-0 right-0 bottom-0 bg-gray-300 rounded-full transition duration-300 ease-in-out">
                                                                <span class="absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition duration-300 ease-in-out"></span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <span id="scan-count" class="text-sm">Scanned: 0</span>
                                                </div>
                                            </div>
                                            
                                            <div class="mt-4 flex space-x-3">
                                                <button id="start-camera" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded">
                                                    <i class="fas fa-video mr-2"></i>Start Camera
                                                </button>
                                                <button id="stop-camera" class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded hidden">
                                                    <i class="fas fa-stop mr-2"></i>Stop Camera
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Search Bar -->
                            <div class="mb-4">
                                <div class="relative">
                                    <input type="text" id="product-search" placeholder="Search products..." 
                                        class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                                    <i class="fas fa-search absolute right-3 top-3 text-gray-400"></i>
                                </div>
                            </div>
                            
                            <!-- Product Grid -->
                            <div class="product-grid">
                                <div class="grid grid-cols-2 md:grid-cols-3 gap-3" id="product-list">
                                    <?php foreach ($products as $product): ?>
                                        <div class="product-item bg-gray-50 rounded-lg p-3 cursor-pointer hover:bg-green-50 border border-gray-200 hover:border-green-300 transition-all"
                                            data-id="<?php echo $product['id']; ?>"
                                            data-name="<?php echo htmlspecialchars($product['name']); ?>"
                                            data-price="<?php echo $product['selling_price']; ?>"
                                            data-stock="<?php echo $product['stock_quantity']; ?>"
                                            data-image="<?php echo htmlspecialchars($product['image_url'] ?? ''); ?>"
                                            data-barcode="<?php echo htmlspecialchars($product['barcode'] ?? ''); ?>">
                                            <?php if (!empty($product['image_url']) && file_exists($product['image_url'])): ?>
                                                <div class="flex justify-center mb-2">
                                                    <img src="<?php echo htmlspecialchars($product['image_url']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="h-16 w-16 object-contain">
                                                </div>
                                            <?php else: ?>
                                                <div class="flex justify-center mb-2">
                                                    <div class="h-16 w-16 bg-gray-200 rounded flex items-center justify-center">
                                                        <i class="fas fa-image text-gray-500"></i>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                            <div class="font-medium text-sm"><?php echo htmlspecialchars($product['name']); ?></div>
                                            <div class="text-green-600 font-semibold text-sm">FRW<?php echo number_format($product['selling_price'], 2); ?></div>
                                            <div class="text-xs text-gray-500">Stock: <?php echo $product['stock_quantity']; ?></div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Cart and Payment -->
                    <div>
                        <div class="bg-white rounded-lg shadow p-4 mb-6">
                            <h3 class="text-lg font-medium text-gray-800 mb-4">Current Sale</h3>
                            <div class="mb-4">
                                <label class="block text-gray-700 text-sm font-bold mb-1">Sale #</label>
                                <input type="text" id="sale-number" value="<?php echo htmlspecialchars($invoice_number); ?>" readonly
                                    class="w-full px-3 py-2 border rounded bg-gray-100 text-sm">
                            </div>
                            
                            <div class="mb-4">
                                <label class="block text-gray-700 text-sm font-bold mb-1">Customer</label>
                                <select id="customer-id" class="w-full px-3 py-2 border rounded text-sm">
                                    <option value="">Walk-in Customer</option>
                                    <?php foreach ($customers as $customer): ?>
                                        <option value="<?php echo $customer['id']; ?>">
                                            <?php echo htmlspecialchars($customer['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="border-t border-b border-gray-200 py-2 mb-4">
                                <div class="flex justify-between mb-1">
                                    <span class="text-gray-600">Subtotal:</span>
                                    <span id="subtotal">FRW0.00</span>
                                </div>
                                <div class="flex justify-between mb-1">
                                    <span class="text-gray-600">Tax (0%):</span>
                                    <span id="tax">FRW0.00</span>
                                </div>
                                <div class="flex justify-between font-bold text-lg">
                                    <span>Total:</span>
                                    <span id="total">FRW0.00</span>
                                </div>
                            </div>
                            
                            <div class="mb-4">
                                <label class="block text-gray-700 text-sm font-bold mb-1">Amount Paid</label>
                                <input type="number" id="amount-paid" min="0" step="0.01"
                                    class="w-full px-3 py-2 border rounded text-sm">
                            </div>
                            
                            <div class="mb-4">
                                <label class="block text-gray-700 text-sm font-bold mb-1">Change</label>
                                <input type="text" id="change" readonly
                                    class="w-full px-3 py-2 border rounded bg-gray-100 text-sm">
                            </div>
                            
                            <div class="mb-4">
                                <label class="block text-gray-700 text-sm font-bold mb-1">Payment Method</label>
                                <select id="payment-method" class="w-full px-3 py-2 border rounded text-sm">
                                    <option value="cash">Cash</option>
                                    <option value="card">Card</option>
                                    <option value="mobile_money">Mobile Money</option>
                                    <option value="bank_transfer">Bank Transfer</option>
                                </select>
                            </div>
                            
                            <button id="process-sale" class="w-full bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded font-medium">
                                Process Sale
                            </button>
                        </div>
                        
                        <div class="bg-white rounded-lg shadow p-4">
                            <div class="flex justify-between items-center mb-3">
                                <h3 class="text-lg font-medium text-gray-800">Cart</h3>
                                <button id="clear-cart" class="text-red-600 hover:text-red-800 text-sm">
                                    <i class="fas fa-trash mr-1"></i> Clear
                                </button>
                            </div>
                            
                            <div id="cart-items" class="space-y-2 max-h-60 overflow-y-auto">
                                <!-- Cart items will be added here dynamically -->
                                <div id="empty-cart-message" class="text-center text-gray-500 py-4">
                                    <i class="fas fa-shopping-cart text-2xl mb-2"></i>
                                    <p>Your cart is empty</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script>
        // POS functionality
        document.addEventListener('DOMContentLoaded', function() {
            let cart = [];
            let lastScannedBarcode = '';
            let scannerInitialized = false;
            
            // User profile dropdown toggle
            const userMenuButton = document.getElementById('user-menu-button');
            const userDropdown = document.getElementById('user-dropdown');
            
            if (userMenuButton && userDropdown) {
                userMenuButton.addEventListener('click', function(e) {
                    e.stopPropagation();
                    userDropdown.classList.toggle('hidden');
                });
                
                // Close dropdown when clicking outside
                document.addEventListener('click', function() {
                    userDropdown.classList.add('hidden');
                });
                
                // Prevent closing when clicking inside dropdown
                userDropdown.addEventListener('click', function(e) {
                    e.stopPropagation();
                });
            }
            
            // Camera Scanner Functionality
            const cameraScanBtn = document.getElementById('camera-scan-btn');
            const continuousScanBtn = document.getElementById('continuous-scan-btn');
            const cameraScannerModal = document.getElementById('camera-scanner-modal');
            const closeCameraModalBtn = document.getElementById('close-camera-modal');
            const startCameraBtn = document.getElementById('start-camera');
            const stopCameraBtn = document.getElementById('stop-camera');
            const scannerVideo = document.getElementById('scanner-video');
            const scannerResult = document.getElementById('scanner-result');
            const scannedBarcode = document.getElementById('scanned-barcode');
            const useScannedBarcodeBtn = document.getElementById('use-scanned-barcode');
            const scannerError = document.getElementById('scanner-error');
            const errorMessage = document.getElementById('error-message');
            const continuousToggle = document.getElementById('continuous-toggle');
            const continuousControls = document.getElementById('continuous-controls');
            const scanCount = document.getElementById('scan-count');
            const scanningModeIndicator = document.getElementById('scanning-mode-indicator');
            
            let stream = null;
            let scanCountValue = 0;
            
            // Open camera scanner modal
            cameraScanBtn.addEventListener('click', function() {
                cameraScannerModal.classList.remove('hidden');
                scannerResult.classList.add('hidden');
                scannerError.classList.add('hidden');
                continuousControls.classList.add('hidden');
                continuousToggle.checked = false;
                scanningModeIndicator.classList.add('hidden');
            });
            
            // Open continuous scanning mode
            continuousScanBtn.addEventListener('click', function() {
                cameraScannerModal.classList.remove('hidden');
                scannerResult.classList.add('hidden');
                scannerError.classList.add('hidden');
                continuousControls.classList.remove('hidden');
                continuousToggle.checked = true;
                scanningModeIndicator.classList.remove('hidden');
                startCamera();
            });
            
            // Close camera scanner modal
            closeCameraModalBtn.addEventListener('click', function() {
                cameraScannerModal.classList.add('hidden');
                stopCamera();
                if (Quagga.initialized) {
                    Quagga.stop();
                    Quagga.initialized = false;
                }
                scanningModeIndicator.classList.add('hidden');
            });
            
            // Close modal when clicking outside
            cameraScannerModal.addEventListener('click', function(e) {
                if (e.target === cameraScannerModal) {
                    cameraScannerModal.classList.add('hidden');
                    stopCamera();
                    if (Quagga.initialized) {
                        Quagga.stop();
                        Quagga.initialized = false;
                    }
                    scanningModeIndicator.classList.add('hidden');
                }
            });
            
            // Toggle continuous scanning mode
            continuousToggle.addEventListener('change', function() {
                if (this.checked) {
                    // Enable continuous mode
                    scanCountValue = 0;
                    scanCount.textContent = 'Scanned: 0';
                } else {
                    // Disable continuous mode
                }
            });
            
            // Start camera
            startCameraBtn.addEventListener('click', function() {
                startCamera();
            });
            
            // Stop camera
            stopCameraBtn.addEventListener('click', function() {
                stopCamera();
            });
            
            // Use scanned barcode (manual override)
            useScannedBarcodeBtn.addEventListener('click', function() {
                if (scannedBarcode.textContent) {
                    addProductByBarcode(scannedBarcode.textContent);
                    scannerResult.classList.add('hidden');
                }
            });
            
            // Start camera function
            function startCamera() {
                scannerError.classList.add('hidden');
                
                // Check if Quagga is available
                if (typeof Quagga === 'undefined') {
                    showError('Barcode scanning library not loaded. Please refresh the page.');
                    return;
                }
                
                // Check for camera access
                if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                    showError('Your browser does not support camera access. Please try a different browser.');
                    return;
                }
                
                // Request camera access
                navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } })
                    .then(function(mediaStream) {
                        stream = mediaStream;
                        scannerVideo.srcObject = stream;
                        
                        // Show stop button and hide start button
                        startCameraBtn.classList.add('hidden');
                        stopCameraBtn.classList.remove('hidden');
                        
                        // Initialize Quagga after video is playing
                        scannerVideo.onloadedmetadata = function() {
                            initializeQuagga();
                        };
                    })
                    .catch(function(err) {
                        console.error('Camera access error:', err);
                        showError('Could not access the camera. Please ensure you have given permission and that no other application is using the camera. Error: ' + err.name);
                    });
            }
            
            // Initialize QuaggaJS for barcode scanning
            function initializeQuagga() {
                if (Quagga.initialized) return;
                
                Quagga.init({
                    inputStream: {
                        name: "Live",
                        type: "LiveStream",
                        target: document.querySelector("#scanner-video"),
                        constraints: {
                            width: 640,
                            height: 480,
                            facingMode: "environment"
                        }
                    },
                    decoder: {
                        readers: [
                            "code_128_reader",
                            "ean_reader",
                            "ean_8_reader",
                            "code_39_reader",
                            "code_39_vin_reader",
                            "codabar_reader",
                            "upc_reader",
                            "upc_e_reader",
                            "i2of5_reader"
                        ]
                    },
                    locate: true
                }, function(err) {
                    if (err) {
                        console.error('Quagga initialization error:', err);
                        showError('Failed to initialize barcode scanner: ' + err.message);
                        return;
                    }
                    
                    Quagga.initialized = true;
                    Quagga.start();
                    
                    // Add detection callback for automatic addition to cart
                    let lastScannedBarcode = '';
                    let lastScanTime = 0;
                    
                    Quagga.onDetected(function(data) {
                        if (data && data.codeResult && data.codeResult.code) {
                            const barcode = data.codeResult.code;
                            const currentTime = new Date().getTime();
                            
                            // Prevent duplicate scans within 1 second
                            if (barcode === lastScannedBarcode && (currentTime - lastScanTime) < 1000) {
                                return;
                            }
                            
                            lastScannedBarcode = barcode;
                            lastScanTime = currentTime;
                            
                            // Automatically add to cart in both modes (no confirmation needed)
                            addProductByBarcode(barcode);
                            
                            // Update scan count if in continuous mode
                            if (continuousToggle.checked) {
                                scanCountValue++;
                                scanCount.textContent = 'Scanned: ' + scanCountValue;
                            }
                            
                            // Play a beep sound to indicate successful scan
                            try {
                                const context = new (window.AudioContext || window.webkitAudioContext)();
                                const oscillator = context.createOscillator();
                                const gainNode = context.createGain();
                                
                                oscillator.connect(gainNode);
                                gainNode.connect(context.destination);
                                
                                oscillator.frequency.value = 800;
                                oscillator.type = 'sine';
                                gainNode.gain.setValueAtTime(0.3, context.currentTime);
                                
                                oscillator.start();
                                gainNode.gain.exponentialRampToValueAtTime(0.00001, context.currentTime + 0.5);
                                
                                setTimeout(() => {
                                    oscillator.stop();
                                }, 500);
                            } catch (e) {
                                // Ignore audio errors
                            }
                            
                            // Show visual feedback
                            showScanFeedback('Product added to cart', 'success');
                        }
                    });
                });
            }
            
            // Stop camera function
            function stopCamera() {
                if (stream) {
                    const tracks = stream.getTracks();
                    tracks.forEach(track => track.stop());
                    stream = null;
                }
                
                // Hide stop button and show start button
                stopCameraBtn.classList.add('hidden');
                startCameraBtn.classList.remove('hidden');
                
                // Stop Quagga if it's running
                if (Quagga.initialized) {
                    Quagga.stop();
                    Quagga.initialized = false;
                }
            }
            
            // Show error message
            function showError(message) {
                errorMessage.textContent = message;
                scannerError.classList.remove('hidden');
            }
            
            // Barcode scanning functionality
            const barcodeInput = document.getElementById('barcode-input');
            const addByBarcodeBtn = document.getElementById('add-by-barcode');
            
            // Focus on barcode input when page loads
            barcodeInput.focus();
            
            // Handle barcode input with more sophisticated detection
            let barcodeBuffer = '';
            let barcodeLastKeyTime = 0;
            
            barcodeInput.addEventListener('keydown', function(e) {
                const currentTime = new Date().getTime();
                
                // If this is the first key or there's been a gap, reset buffer
                if (barcodeBuffer === '' || (currentTime - barcodeLastKeyTime) > 100) {
                    barcodeBuffer = '';
                }
                
                barcodeLastKeyTime = currentTime;
                
                // Add key to buffer (but not Enter key)
                if (e.key !== 'Enter') {
                    barcodeBuffer += e.key;
                }
                
                // If Enter is pressed or we have enough characters (assume scanner input)
                if (e.key === 'Enter' || barcodeBuffer.length >= 4) {
                    // Process the barcode after a short delay to allow for full input
                    setTimeout(function() {
                        if (barcodeBuffer.length >= 4) { // Minimum barcode length
                            addProductByBarcode(barcodeBuffer);
                        }
                        barcodeBuffer = '';
                    }, 50);
                }
            });
            
            // Handle manual add button click
            addByBarcodeBtn.addEventListener('click', function() {
                if (barcodeInput.value.trim() !== '') {
                    addProductByBarcode(barcodeInput.value.trim());
                    barcodeInput.value = '';
                    barcodeInput.focus();
                }
            });
            
            // Function to add product by barcode
            function addProductByBarcode(barcode) {
                if (barcode === '') {
                    return;
                }
                
                // Prevent duplicate scans (in case of scanner sending same code twice)
                if (barcode === lastScannedBarcode) {
                    // Small delay to prevent duplicate scanning
                    setTimeout(() => { lastScannedBarcode = ''; }, 1000);
                    return;
                }
                
                lastScannedBarcode = barcode;
                
                // Find product with matching barcode
                const productItems = document.querySelectorAll('.product-item');
                let foundProduct = null;
                
                for (let item of productItems) {
                    // Get barcode from data attribute
                    const itemBarcode = item.getAttribute('data-barcode');
                    if (itemBarcode === barcode) {
                        foundProduct = item;
                        break;
                    }
                }
                
                if (foundProduct) {
                    // Simulate click on the product item to add it to cart
                    foundProduct.click();
                    // Show visual feedback
                    showScanFeedback('Product added to cart: ' + foundProduct.getAttribute('data-name'), 'success');
                    // Clear input and refocus
                    barcodeInput.value = '';
                    barcodeInput.focus();
                } else {
                    // Show visual feedback
                    showScanFeedback('Product not found: ' + barcode, 'error');
                    // Clear input and refocus
                    barcodeInput.value = '';
                    barcodeInput.focus();
                }
                
                // Reset last scanned after delay
                setTimeout(() => { lastScannedBarcode = ''; }, 1000);
            }
            
            // Function to show scan feedback
            function showScanFeedback(message, type) {
                // Remove any existing feedback
                const existingFeedback = document.getElementById('scan-feedback');
                if (existingFeedback) {
                    existingFeedback.remove();
                }
                
                // Create feedback element
                const feedback = document.createElement('div');
                feedback.id = 'scan-feedback';
                feedback.className = `fixed top-4 right-4 px-4 py-2 rounded-lg shadow-lg z-50 ${
                    type === 'success' ? 'bg-green-500 text-white' : 'bg-red-500 text-white'
                }`;
                feedback.textContent = message;
                feedback.style.transition = 'opacity 0.5s';
                
                // Add to document
                document.body.appendChild(feedback);
                
                // Auto remove after 2 seconds with fade effect
                setTimeout(() => {
                    feedback.style.opacity = '0';
                    setTimeout(() => {
                        if (feedback.parentNode) {
                            feedback.parentNode.removeChild(feedback);
                        }
                    }, 500);
                }, 2000);
            }
            
            // Product search functionality
            const productSearch = document.getElementById('product-search');
            const productList = document.getElementById('product-list');
            
            productSearch.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase();
                const productItems = productList.querySelectorAll('.product-item');
                
                productItems.forEach(item => {
                    const productName = item.getAttribute('data-name').toLowerCase();
                    if (productName.includes(searchTerm)) {
                        item.style.display = 'block';
                    } else {
                        item.style.display = 'none';
                    }
                });
            });
            
            // Add product to cart
            productList.addEventListener('click', function(e) {
                const productItem = e.target.closest('.product-item');
                if (productItem) {
                    // Add animation class when product is clicked
                    productItem.classList.add('added-to-cart');
                    
                    // Remove animation class after animation completes
                    setTimeout(() => {
                        productItem.classList.remove('added-to-cart');
                    }, 500);
                    
                    const productId = productItem.getAttribute('data-id');
                    const productName = productItem.getAttribute('data-name');
                    const productPrice = parseFloat(productItem.getAttribute('data-price'));
                    const productStock = parseInt(productItem.getAttribute('data-stock'));
                    // Get image URL from the product item
                    const productImage = productItem.getAttribute('data-image') || '';
                    // Get barcode from the product item
                    const productBarcode = productItem.getAttribute('data-barcode') || '';
                    
                    // Check if product is already in cart
                    const existingItem = cart.find(item => item.id == productId);
                    
                    if (existingItem) {
                        // If already in cart, increase quantity if stock allows
                        if (existingItem.quantity < productStock) {
                            existingItem.quantity++;
                            existingItem.total = existingItem.quantity * productPrice;
                            // Show feedback for quantity increase
                            if (productBarcode === lastScannedBarcode) {
                                showScanFeedback('Quantity increased for ' + productName, 'success');
                            }
                        } else {
                            showScanFeedback('Not enough stock available for ' + productName, 'error');
                            return;
                        }
                    } else {
                        // Add new item to cart
                        if (productStock > 0) {
                            cart.push({
                                id: productId,
                                name: productName,
                                price: productPrice,
                                quantity: 1,
                                total: productPrice,
                                image: productImage,
                                barcode: productBarcode
                            });
                            // Show feedback for new item
                            if (productBarcode === lastScannedBarcode) {
                                showScanFeedback('Product added to cart: ' + productName, 'success');
                            }
                        } else {
                            showScanFeedback('Product out of stock: ' + productName, 'error');
                            return;
                        }
                    }
                    
                    updateCartDisplay();
                    calculateTotals();
                }
            });
            
            // Update cart display
            function updateCartDisplay() {
                const cartItemsContainer = document.getElementById('cart-items');
                const emptyCartMessage = document.getElementById('empty-cart-message');
                
                if (cart.length === 0) {
                    cartItemsContainer.innerHTML = '<div id="empty-cart-message" class="text-center text-gray-500 py-4"><i class="fas fa-shopping-cart text-2xl mb-2"></i><p>Your cart is empty</p></div>';
                    return;
                }
                
                // Remove empty cart message
                if (emptyCartMessage) {
                    emptyCartMessage.remove();
                }
                
                // Clear current cart items
                cartItemsContainer.innerHTML = '';
                
                // Add items to cart
                cart.forEach((item, index) => {
                    // Create image element for cart item
                    let imageHtml = '';
                    if (item.image && item.image.trim() !== '') {
                        imageHtml = `<img src="${item.image}" alt="${item.name}" class="w-12 h-12 object-contain rounded">`;
                    } else {
                        imageHtml = `<div class="w-12 h-12 bg-gray-200 rounded flex items-center justify-center">
                                        <i class="fas fa-image text-gray-500"></i>
                                     </div>`;
                    }
                    
                    const cartItem = document.createElement('div');
                    cartItem.className = 'cart-item flex items-center justify-between p-2 border-b border-gray-100';
                    cartItem.innerHTML = `
                        <div class="flex items-center">
                            ${imageHtml}
                            <div class="ml-2">
                                <div class="font-medium text-sm">${item.name}</div>
                                <div class="text-xs text-gray-500">FRW${item.price.toFixed(2)} x ${item.quantity}</div>
                            </div>
                        </div>
                        <div class="flex items-center">
                            <span class="font-medium mr-2">FRW${item.total.toFixed(2)}</span>
                            <button class="remove-item text-red-500 hover:text-red-700" data-index="${index}">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    `;
                    cartItemsContainer.appendChild(cartItem);
                });
                
                // Add event listeners to remove buttons
                document.querySelectorAll('.remove-item').forEach(button => {
                    button.addEventListener('click', function() {
                        const index = parseInt(this.getAttribute('data-index'));
                        cart.splice(index, 1);
                        updateCartDisplay();
                        calculateTotals();
                    });
                });
            }
            
            // Calculate totals
            function calculateTotals() {
                const subtotal = cart.reduce((sum, item) => sum + item.total, 0);
                const tax = 0; // For simplicity, no tax in this example
                const total = subtotal + tax;
                
                document.getElementById('subtotal').textContent = 'FRW' + subtotal.toFixed(2);
                document.getElementById('tax').textContent = 'FRW' + tax.toFixed(2);
                document.getElementById('total').textContent = 'FRW' + total.toFixed(2);
                
                // Automatically set amount paid to total amount
                const amountPaidInput = document.getElementById('amount-paid');
                if (amountPaidInput.value === '' || parseFloat(amountPaidInput.value) === 0) {
                    amountPaidInput.value = total.toFixed(2);
                }
                
                // Calculate change
                const amountPaid = parseFloat(amountPaidInput.value) || 0;
                const change = amountPaid - total;
                document.getElementById('change').value = change >= 0 ? 'FRW' + change.toFixed(2) : 'FRW0.00';
            }
            
            // Update totals when amount paid changes
            document.getElementById('amount-paid').addEventListener('input', function() {
                // Only recalculate change, don't auto-set amount paid
                const subtotal = cart.reduce((sum, item) => sum + item.total, 0);
                const tax = 0; // For simplicity, no tax in this example
                const total = subtotal + tax;
                
                // Calculate change
                const amountPaid = parseFloat(this.value) || 0;
                const change = amountPaid - total;
                document.getElementById('change').value = change >= 0 ? 'FRW' + change.toFixed(2) : 'FRW0.00';
            });
            
            // Clear cart
            document.getElementById('clear-cart').addEventListener('click', function() {
                if (cart.length > 0 && confirm('Are you sure you want to clear the cart?')) {
                    cart = [];
                    updateCartDisplay();
                    calculateTotals();
                    document.getElementById('amount-paid').value = '';
                    document.getElementById('change').value = '';
                }
            });
            
            // Process sale
            document.getElementById('process-sale').addEventListener('click', function() {
                if (cart.length === 0) {
                    alert('Please add items to the cart before processing the sale.');
                    return;
                }
                
                const total = cart.reduce((sum, item) => sum + item.total, 0);
                let amountPaid = parseFloat(document.getElementById('amount-paid').value) || 0;
                
                // If amount paid is 0 or empty, default to total amount
                if (amountPaid === 0) {
                    amountPaid = total;
                    document.getElementById('amount-paid').value = total.toFixed(2);
                }
                
                // Check if amount paid is sufficient
                if (amountPaid < total) {
                    alert('Amount paid is less than the total amount.');
                    return;
                }
                
                // Get selected customer ID
                let customerId = document.getElementById('customer-id').value || null;
                
                // Validate customer ID - if it's an empty string, set to null
                if (customerId === '') {
                    customerId = null;
                }
                
                const paymentMethod = document.getElementById('payment-method').value;
                
                // Show processing message
                const processButton = document.getElementById('process-sale');
                const originalText = processButton.innerHTML;
                processButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
                processButton.disabled = true;
                
                // Send data to server
                const formData = new FormData();
                formData.append('action', 'process_sale');
                if (customerId !== null) {
                    formData.append('customer_id', customerId);
                }
                formData.append('cart_items', JSON.stringify(cart));
                formData.append('payment_method', paymentMethod);
                formData.append('amount_paid', amountPaid);
                
                fetch('pos.php', {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        // Clear cart and show success message
                        cart = [];
                        updateCartDisplay();
                        calculateTotals();
                        document.getElementById('amount-paid').value = '';
                        document.getElementById('change').value = '';
                        
                        // Show success message
                        alert(data.message);
                    } else {
                        // Show error message
                        alert('Error: ' + data.message);
                    }
                    // Reset button
                    processButton.innerHTML = originalText;
                    processButton.disabled = false;
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error processing sale. Please try again.');
                    // Reset button
                    processButton.innerHTML = originalText;
                    processButton.disabled = false;
                });
            });
        });
    </script>
</body>
</html>