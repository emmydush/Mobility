<?php
include '../api/config/database.php';

echo "Listing all users in the database:\n";
echo "==================================\n";

// Get all users with their creation dates
$query = "SELECT id, username, email, role, created_at FROM users ORDER BY created_at";
$stmt = $conn->prepare($query);
if ($stmt) {
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        while ($user = $result->fetch_assoc()) {
            echo "ID: " . $user['id'] . "\n";
            echo "Username: " . $user['username'] . "\n";
            echo "Email: " . $user['email'] . "\n";
            echo "Role: " . $user['role'] . "\n";
            echo "Created: " . $user['created_at'] . "\n";
            echo "------------------------\n";
        }
    } else {
        echo "No users found in the database.\n";
    }
    $stmt->close();
} else {
    echo "Database error: " . $conn->error . "\n";
}

$conn->close();
?>