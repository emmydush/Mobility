<?php
// Redirect to the modern login page
header("Location: modern_login.php");
exit();
?>